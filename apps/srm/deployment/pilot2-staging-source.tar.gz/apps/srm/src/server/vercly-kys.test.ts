import assert from "node:assert/strict";
import test from "node:test";
import { fetchVerclyKys } from "./vercly-kys";

const request = { identifier: { type: "NIP" as const, value: "5272443955" } };

function response(value: unknown, status = 200): Response {
  return new Response(JSON.stringify(value), { status, headers: { "Content-Type": "application/json" } });
}

test("NIP-only request omits phone, name and FULL, then keeps an allowlisted report", async () => {
  const calls: Array<{ url: string; init?: RequestInit }> = [];
  const fetcher = (async (url: string | URL | Request, init?: RequestInit) => {
    calls.push({ url: String(url), init });
    if (calls.length === 1) return response(["correlation123"]);
    if (calls.length === 2) return response([{ Header: { CorrelationId: "correlation123" }, Body: { IsComplete: false } }]);
    return response([{ Header: { CorrelationId: "correlation123", Id: "report456" }, Body: {
      IsComplete: true, QueriedRegisters: ["Regon"], Errors: [{ Severity: 0, Message: "private provider message" }],
      Entity: { Name: "XTB SPÓŁKA AKCYJNA", Ids: [{ Type: "KRS", Value: "0000217580" }, { Type: "VatID", Value: "PL5272443955" }],
        Krz: { Count: 0 }, Vat: { ActivityStatus: "Czynny" }, Vies: { EuVat: true },
        DepPersons: { Count: 1, Persons: [{ Name: "PRIVATE PERSON", PersonalId: "12345678901" }] },
        Sanctions: [{ ListName: "eu_fsf_sanctions", ListType: "SANCTIONS", Value: false }],
      },
    } }]);
  }) as typeof fetch;
  const result = await fetchVerclyKys(request, { apiKey: "test-token", baseUrl: "https://vercly.example", fetcher, sleep: async () => {} });
  assert.equal(calls.length, 3);
  assert.deepEqual(JSON.parse(String(calls[0].init?.body)), [{ Id: "5272443955", Country: "PL" }]);
  assert.equal(result.section.status, "PARTIAL");
  assert.equal(result.section.data?.company?.krs, "0000217580");
  assert.equal(result.section.data?.company?.nip, "5272443955");
  assert.equal(result.section.data?.relatedPersonsCount, 1);
  assert.deepEqual(result.section.data?.registryChecks, { krzListed: false, vatActive: true, euVat: true });
  assert.ok(!JSON.stringify(result.section).includes("PRIVATE PERSON"));
  assert.ok(!JSON.stringify(result.section).includes("private provider message"));
});

test("rejects a result for a different NIP", async () => {
  let calls = 0;
  const fetcher = (async () => ++calls === 1 ? response(["correlation123"]) : response([{
    Header: { CorrelationId: "correlation123" }, Body: { IsComplete: true, Entity: { Ids: [{ Type: "ID", Value: "8650004194" }] } },
  }])) as typeof fetch;
  const result = await fetchVerclyKys(request, { apiKey: "test-token", baseUrl: "https://vercly.example", fetcher, sleep: async () => {} });
  assert.equal(result.errorCode, "IDENTIFIER_MISMATCH");
  assert.equal(result.section.data, null);
});

test("accepts a completed sole proprietor report when VatID matches the JDG NIP", async () => {
  const jdgRequest = { identifier: { type: "NIP" as const, value: "7972088368" } };
  let calls = 0;
  const fetcher = (async () => ++calls === 1 ? response(["jdgCorrelation123"]) : response([{
    Header: { CorrelationId: "jdgCorrelation123", Id: "jdgReport123" },
    Body: { IsComplete: true, Errors: [{ Severity: 0, Resolved: true, Registry: "vat.whitelist.fetched" }], Entity: {
      Name: "Przykładowa JDG",
      Ids: [{ Type: "ID", Value: "different-internal-id" }, { Type: "VatID", Value: "PL7972088368" }],
      Attributes: [{ Name: "NormalizedDetailLegalForm", Value: "SOLE_PROPRIETORSHIP" }],
      Sanctions: [{ ListName: "uk_ofsi_sanctions", ListType: "SANCTIONS", Value: false }],
    } },
  }])) as typeof fetch;
  const result = await fetchVerclyKys(jdgRequest, { apiKey: "test-token", baseUrl: "https://vercly.example", fetcher, sleep: async () => {} });
  assert.equal(result.section.status, "SUCCESS");
  assert.deepEqual(result.section.warnings, []);
  assert.equal(result.section.data?.company?.nip, "7972088368");
  assert.equal(result.section.data?.company?.krs, null);
  assert.equal(result.section.data?.company?.legalForm, "SOLE_PROPRIETORSHIP");
  assert.equal(result.section.data?.screenedLists?.[0]?.matched, false);
});

test("FULL report keeps confirmed persons and complete PESEL values without raw provider records", async () => {
  let calls = 0;
  const fetcher = (async () => ++calls === 1 ? response(["personCorrelation123"]) : response([{
    Header: { CorrelationId: "personCorrelation123", Id: "personReport123" },
    Body: { IsComplete: true, Entity: {
      Ids: [{ Type: "VatID", Value: "PL5272443955" }],
      Beneficiaries: { Count: 1, Values: [{ FullName: "Jan Przykładowy", Pesel: "12345678901",
        Mandates: [{ Description: "Beneficjent rzeczywisty" }], Citizens: [{ Name: "POLSKA" }],
        Source: "CRBR", FoundIn: [{ Type: "Spółka z ograniczoną odpowiedzialnością" }], Sanctions: [{ ListName: "uk_ofsi_sanctions", Value: false }],
        PepPositions: { Count: 1, Details: [{ SearchPhrase: "JAN PRZYKŁADOWY", Name: "PRZYKŁADOWY JAN",
          Score: "0.90", Dob: "1980-01-01", Aliases: ["JAN P."],
          Positions: ["CZŁONEK RADY W SPÓŁCE SKARBU PAŃSTWA"], IdNumber: ["12345678901"],
          SecretProviderField: "private PEP source value" }] }, SecretProviderField: "private raw value" }] },
      DepPersons: { Count: 1, Values: [{ FullName: "Anna Testowa", Pesel: "10987654321",
        PositionsHeld: ["CZŁONEK ZARZĄDU"], Sanctions: [{ ListName: "uk_ofsi_sanctions", Value: true }],
        PepPositions: { Count: 1 } }] },
      PepPositions: { Count: 0 },
    } },
  }])) as typeof fetch;
  const result = await fetchVerclyKys(request, { apiKey: "test-token", baseUrl: "https://vercly.example", fetcher, sleep: async () => {} });
  assert.equal(result.section.status, "SUCCESS");
  assert.deepEqual(result.section.data?.beneficialOwners, [{
    fullName: "Jan Przykładowy", pesel: "12345678901", birthDate: null,
    positions: ["Beneficjent rzeczywisty"], citizenship: ["POLSKA"], foundIn: ["CRBR"],
    sanctionsMatch: false, pepMatch: true,
  }]);
  assert.equal(result.section.data?.relatedPersons?.[0]?.pesel, "10987654321");
  assert.equal(result.section.data?.relatedPersons?.[0]?.sanctionsMatch, true);
  assert.equal(result.section.data?.relatedPersons?.[0]?.pepMatch, true);
  assert.equal(result.section.data?.pepPositionsCount, 2);
  assert.deepEqual(result.section.data?.pepMatches?.[0], {
    personGroup: "beneficialOwners", personIndex: 0, personName: "Jan Przykładowy",
    searchPhrase: "JAN PRZYKŁADOWY", matchedName: "PRZYKŁADOWY JAN", aliases: ["JAN P."],
    birthDate: "1980-01-01", positions: ["CZŁONEK RADY W SPÓŁCE SKARBU PAŃSTWA"],
    probabilityPercent: 90, identifierMatchesPesel: true,
  });
  assert.equal(result.section.data?.pepMatches?.[1]?.personGroup, "relatedPersons");
  assert.equal(result.section.data?.pepMatches?.[1]?.matchedName, null);
  assert.ok(!JSON.stringify(result.section).includes("private raw value"));
  assert.ok(!JSON.stringify(result.section).includes("private PEP source value"));
  assert.ok(!JSON.stringify(result.section.data?.pepMatches).includes("12345678901"));
});

test("retries temporary 404 while Vercly prepares the report", async () => {
  let calls = 0;
  const sleeps: number[] = [];
  const fetcher = (async () => {
    calls += 1;
    if (calls === 1) return response(["correlation123"]);
    if (calls <= 3) return response({ error: "not ready" }, 404);
    return response([{ Header: { CorrelationId: "correlation123" }, Body: {
      IsComplete: true, Entity: { Ids: [{ Type: "VatID", Value: "PL5272443955" }] },
    } }]);
  }) as typeof fetch;
  const result = await fetchVerclyKys(request, { apiKey: "test-token", baseUrl: "https://vercly.example", fetcher,
    sleep: async (ms) => { sleeps.push(ms); }, pollIntervalMs: 2000 });
  assert.equal(result.section.status, "SUCCESS");
  assert.deepEqual(sleeps, [2000, 2000, 2000]);
  assert.deepEqual(result.section.data?.registryChecks, { krzListed: null, vatActive: null, euVat: null });
});

test("rate-limit Retry-After and transient statuses respect a single POST-to-result monotonic budget", async () => {
  let elapsed = 0, calls = 0; const waits: number[] = [];
  const fetcher = (async (_url: unknown, init: RequestInit) => {
    calls++; if (calls === 1) { assert.equal(init.method, "POST"); elapsed += 1000; return response(["correlation123"]); }
    if (calls === 2) return new Response("{}", { status: 429, headers: { "Retry-After": "4" } });
    return response([{ Header: { CorrelationId: "correlation123" }, Body: { IsComplete: true, Entity: { Ids: [{ Type: "VatID", Value: "PL5272443955" }] } } }]);
  }) as typeof fetch;
  const result = await fetchVerclyKys(request, { apiKey: "fixture", baseUrl: "https://vercly.example", fetcher, elapsedNow: () => elapsed, pollTimeoutMs: 10000, pollIntervalMs: 2000, sleep: async ms => { waits.push(ms); elapsed += ms; } });
  assert.equal(result.section.status, "SUCCESS"); assert.deepEqual(waits, [2000, 4000]); assert.equal(calls, 3);
});
test("pending report stops at the unified deadline; POST is never retried after an ambiguous transport failure", async () => {
  let elapsed = 0, calls = 0;
  const pending = (async () => ++calls === 1 ? response(["correlation123"]) : response([{ Header: { CorrelationId: "correlation123" }, Body: { IsComplete: false } }])) as typeof fetch;
  const result = await fetchVerclyKys(request, { apiKey: "fixture", baseUrl: "https://vercly.example", fetcher: pending, elapsedNow: () => elapsed, pollTimeoutMs: 5000, sleep: async ms => { elapsed += ms; } });
  assert.equal(result.errorCode, "VERCLY_TIMEOUT"); assert.equal(elapsed, 5000); assert.equal(calls, 2);
  calls = 0;
  const ambiguous = await fetchVerclyKys(request, { apiKey: "fixture", baseUrl: "https://vercly.example", fetcher: (async () => { calls++; throw new Error("connection reset"); }) as typeof fetch });
  assert.equal(ambiguous.errorCode, "VERCLY_POST_OUTCOME_UNKNOWN"); assert.equal(calls, 1);
});
