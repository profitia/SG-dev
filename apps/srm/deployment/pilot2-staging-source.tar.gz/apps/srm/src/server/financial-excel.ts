import ExcelJS from "exceljs";
import { financialQualityIssues, financialQualityLabels, financialLabels, type FinancialData, type FinancialPeriod } from "@profitia/srm-xray";

type Scope = FinancialPeriod["scope"];
import { financialRowPresentation } from "./financial-schema-labels";
import type { FinancialSourceDocument, FinancialSourceRow } from "./financial-documents";

export type FinancialExcelSelection = { nip: string; scope: Scope; years: string[] };

export function validateFinancialExcelSelection(input: unknown): FinancialExcelSelection {
  if (!input || typeof input !== "object" || Array.isArray(input)) throw new Error("Nieprawidłowy wybór danych.");
  const value = input as Record<string, unknown>;
  if (typeof value.nip !== "string" || !/^\d{10}$/.test(value.nip)) throw new Error("Nieprawidłowy NIP.");
  if (value.scope !== "standalone" && value.scope !== "consolidated") throw new Error("Wybierz rodzaj sprawozdania.");
  if (!Array.isArray(value.years) || !value.years.length || value.years.length > 100 ||
      value.years.some((year) => typeof year !== "string" || !/^\d{4}$/.test(year)) ||
      new Set(value.years).size !== value.years.length) throw new Error("Wybierz dostępne lata.");
  return { nip: value.nip, scope: value.scope, years: value.years as string[] };
}

function complete(period: FinancialPeriod): boolean {
  if (period.accountingStandard === "IAS_IFRS") return Boolean(period.msrRows?.some(r=>r.section === "Bilans") && period.msrRows?.some(r=>r.section === "RZiS"));
  return period.facts.some((fact) => fact.metricCode.startsWith("BS_"))
    && period.facts.some((fact) => fact.metricCode.startsWith("PALA_"));
}

/** Match the dashboard's best-report-per-year rule without asking MGBI again. */
export function periodsForExcel(data: FinancialData, scope: Scope): FinancialPeriod[] {
  const candidates = data.periods.filter((period) => period.scope === scope && (period.facts.length > 0 || period.msrRows?.length) && /^\d{4}-\d{2}-\d{2}$/.test(period.to))
    .sort((a, b) => b.to.localeCompare(a.to) || Number(complete(b)) - Number(complete(a)) || b.facts.length - a.facts.length);
  const byYear = new Map<string, FinancialPeriod>();
  for (const period of candidates) {
    const year = period.to.slice(0, 4);
    const previous = byYear.get(year);
    const quality = (item: FinancialPeriod) => (complete(item) ? 100000 : 0) + item.facts.length;
    if (!previous || quality(period) > quality(previous)) byYear.set(year, period);
  }
  return [...byYear.values()].sort((a, b) => b.to.localeCompare(a.to));
}

/** Preserve source decimals. Excel's fifteen-digit limit must never silently round a source amount. */
export function exactExcelAmount(amount: string | null): string | number | null {
  if (amount === null) return null;
  const significant = amount.replace(/^-/, "").replace(".", "").replace(/^0+/, "");
  return significant.length <= 15 && Number.isFinite(Number(amount)) ? Number(amount) : amount;
}

export function financialExcelDate(now: Date): string {
  const parts = Object.fromEntries(new Intl.DateTimeFormat("en-GB", {
    timeZone: "Europe/Warsaw", year: "numeric", month: "2-digit", day: "2-digit",
  }).formatToParts(now).map((part) => [part.type, part.value]));
  return `${parts.year}${parts.month}${parts.day}`;
}

function addSheet(workbook: ExcelJS.Workbook, name: string, section: "Bilans" | "RZiS", documents: readonly { document: FinancialSourceDocument; years: string[] }[]): void {
  const sheet = workbook.addWorksheet(name, { views: [{ state: "frozen", xSplit: 1, ySplit: 1 }] });
  sheet.getColumn(1).width = 85;
  const columns = documents.flatMap(({ document, years }) => document.columns.map((column, columnIndex) => ({ document, column, columnIndex, years })));
  const header = sheet.addRow(["Pozycja", ...columns.map(({ document, column, columnIndex, years }) =>
    (column.from && column.to ? `${column.from} – ${column.to}` : `Kolumna ${columnIndex + 1} · okres nieustalony · ${years.join(", ")}`)
      + ` (${document.currency ?? "waluta nieustalona"}${document.scale === "1000" ? ", tys." : ""})`)]);
  header.font = { bold: true, color: { argb: "FFFFFFFF" } };
  header.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF242F44" } };
  header.alignment = { wrapText: true, vertical: "middle" }; header.height = 55;
  columns.forEach((_, index) => {
    sheet.getColumn(index + 2).width = 29;
  });
  type DisplayRow = { label: string; depth: number; order: number; family: string; sources: Map<string, { row: FinancialSourceRow }> };
  const rows = new Map<string, DisplayRow>();
  for (const { document } of documents) for (const item of document.rows.filter(row => row.section === section)) {
    const presentation = financialRowPresentation(document, item);
    const family = document.schemaName?.replace(/(WZlotych|WTysiacach(?:Zlotych)?)$/, "") ?? document.schemaName ?? "";
    // Merge only the same source position with the same verified meaning across selected documents.
    // Amounts always stay in that document's own columns; name or amount alone is never an identity.
    const key = JSON.stringify([family, item.sourcePath.replaceAll(">", "."), presentation.label]);
    let row = rows.get(key);
    if (!row) { row = { label: presentation.label, depth: item.depth, order: presentation.order, family, sources: new Map() }; rows.set(key, row); }
    row.sources.set(document.recordId, { row: item });
  }
  for (const item of [...rows.values()].sort((a, b) => a.family.localeCompare(b.family) || a.order - b.order ||
    [...a.sources.values()][0].row.sourcePath.localeCompare([...b.sources.values()][0].row.sourcePath, "pl", { numeric: true }))) {
    // Explicit string cells prevent a provider label beginning '=' or '+' becoming a formula.
    const row = sheet.addRow([item.label, ...columns.map(({ document, column }) => exactExcelAmount(item.sources.get(document.recordId)?.row.amounts[column.sourceColumn] ?? null))]);
    row.getCell(1).alignment = { indent: Math.min(7, Math.max(0, item.depth - (section === "RZiS" ? 2 : 1))), wrapText: true };
    row.outlineLevel = Math.min(7, Math.max(0, item.depth - (section === "RZiS" ? 2 : 1)));
    for (let index = 0; index < columns.length; index++) {
      const { document, column } = columns[index];
      const source = item.sources.get(document.recordId), amount = source?.row.amounts[column.sourceColumn];
      const cell = row.getCell(index + 2);
      if (typeof cell.value === "number") cell.numFmt = "#,##0" + (amount?.includes(".") ? "." + "0".repeat(amount.split(".")[1].length) : "");
    }
  }
  sheet.autoFilter = { from: "A1", to: { row: sheet.rowCount, column: columns.length + 1 } };
  sheet.pageSetup = { fitToPage: true, fitToWidth: 1, fitToHeight: 0, orientation: "landscape", printTitlesRow: "1:1" };
}

function registrySources(sheet: ExcelJS.Worksheet, periods: readonly FinancialPeriod[]): void {
  if (!periods.some(p=>p.sourceRegistration)) return;
  sheet.addRow(["Pochodzenie sprawozdań — zachowane KRS podmiotów składających"]);
  sheet.addRow(["Okres od","Okres do","Podmiot składający","KRS źródłowy","Relacja"]);
  for (const p of periods) sheet.addRow([p.from,p.to,p.sourceRegistration?.legalName ?? "niepotwierdzony",p.sourceRegistration?.krs ?? "niepotwierdzony",
    p.sourceRegistration?.relationship === "PREDECESSOR" ? "Poprzednik przed przekształceniem" : p.sourceRegistration?.relationship === "CURRENT" ? "Aktualny podmiot" : "Relacja niepotwierdzona"]);
  sheet.addRow(["Porównywalność","Ciągłość rejestrowa nie zastępuje potwierdzenia zgodności standardu, zakresu i okresów sprawozdawczych."]);
}

/** Preserve source amounts; disclose quality and alternative comparisons alongside them. */
function qualitySheet(workbook: ExcelJS.Workbook, periods: readonly FinancialPeriod[]): void {
  if (!periods.some(p => financialQualityIssues(p).length || p.comparativeData)) return;
  const sheet = workbook.addWorksheet("Jakość danych");
  sheet.columns = [50, 65, 32, 32, 28].map(width=>({width}));
  sheet.addRow(["Okres / zakres", "Uwaga / pozycja", "Dane zwykłe", "Dane przekształcone", "Jednostka"]);
  sheet.getRow(1).font = {bold: true};
  for (const p of periods) {
    const title = `${p.from} – ${p.to} · ${p.scope === "standalone" ? "jednostkowe" : "skonsolidowane"}`;
    for (const issue of financialQualityIssues(p)) sheet.addRow([title,financialQualityLabels[issue]]);
    if (!p.comparativeData) continue;
    sheet.addRow([title,p.comparativeData.dateBasis === "UNCONFIRMED" ? "Okres danych przekształconych niepotwierdzony" : "Poprzedni rok kalendarzowy"]);
    const {original,restated}=p.comparativeData;
    for (const code of new Set([...original,...restated].map(f=>f.metricCode))) {
      const a=original.find(f=>f.metricCode===code), b=restated.find(f=>f.metricCode===code);
      sheet.addRow([title,financialLabels[code]?.label ?? "Pozycja źródłowa",exactExcelAmount(a?.amount ?? null),exactExcelAmount(b?.amount ?? null),
        a?.unit === b?.unit ? a?.unit : `zwykłe: ${a?.unit ?? "brak"}; przekształcone: ${b?.unit ?? "brak"}`]);
    }
  }
}

export async function buildFinancialExcel(data: FinancialData, selection: FinancialExcelSelection, now = new Date(), sourceDocuments: readonly FinancialSourceDocument[] = []): Promise<{ filename: string; bytes: Buffer }> {
  const available = new Map(periodsForExcel(data, selection.scope).map((period) => [period.to.slice(0, 4), period]));
  if (selection.years.some((year) => !available.has(year))) throw new Error("Wybrane lata nie są dostępne w zapisanym raporcie.");
  const selected = new Map<string, { document: FinancialSourceDocument; years: string[] }>();
  const selectedPeriods = selection.years.map(year=>available.get(year)!);
  if (selectedPeriods.every(p=>p.accountingStandard === "IAS_IFRS")) {
    for (const period of selectedPeriods) if (!sourceDocuments.some(d=>d.recordId === period.documentId.replace(/:(cfy|pfy)$/,"") && d.scope === selection.scope && ["IXBRL_SUPPORTED","XHTML_SUPPORTED"].includes(d.availability)))
      throw new Error("Oryginalne dane MSR nie są dostępne w tej organizacji.");
    const workbook = new ExcelJS.Workbook(); workbook.creator="SRM X-Ray";workbook.created=now;
    const sheet=workbook.addWorksheet("MSR_MSSF",{views:[{state:"frozen",xSplit:3,ySplit:1}]});
    sheet.columns=[{header:"Sekcja",key:"section",width:24},{header:"Pozycja",key:"label",width:75},{header:"Jednostka",key:"unit",width:18},
      ...selectedPeriods.map((p,i)=>({header:p.from+" – "+p.to,key:"p"+i,width:28}))];
    const rows=new Map<string,NonNullable<FinancialPeriod["msrRows"]>[number]>();
    for (const p of selectedPeriods) for(const r of p.msrRows ?? []) rows.set(r.section+":"+r.key,r);
    for(const [key,r] of rows) sheet.addRow([r.section,r.label,r.currency ?? r.unit,
      ...selectedPeriods.map(p=>{const v=p.msrRows?.find(v=>v.section+":"+v.key===key);return v?.validation === "VALID" ? exactExcelAmount(v.amount) : "DO WERYFIKACJI / BRAK DANYCH";})]);
    sheet.getRow(1).font={bold:true};
    const meta=workbook.addWorksheet("Źródła");meta.addRow(["Standard","MSR/MSSF · XHTML/iXBRL"]);
    meta.addRow(["NIP",selection.nip]);meta.addRow(["Zakres",selection.scope]);meta.addRow(["Wartości","Jednostki podstawowe po zastosowaniu skali iXBRL; zachowane znaki źródłowe"]);
    for(const d of sourceDocuments.filter(d=>selectedPeriods.some(p=>p.documentId.startsWith(d.recordId+":")))) meta.addRow(["Dokument MGBI",d.recordId,d.checksum,d.mappingVersion]);
    registrySources(meta,selectedPeriods);
    qualitySheet(workbook,selectedPeriods);
    return {filename:`Financials_MSR_${selection.nip}_${financialExcelDate(now)}.xlsx`,bytes:Buffer.from(await workbook.xlsx.writeBuffer())};
  }
  if (selectedPeriods.some(p=>p.accountingStandard === "IAS_IFRS")) throw new Error("Wybierz lata o jednym standardzie sprawozdawczym do jednego eksportu.");
  for (const year of [...selection.years].sort().reverse()) {
    const period = available.get(year)!;
    const recordId = period.documentId.replace(/:(cfy|pfy)$/, "");
    const document = sourceDocuments.find((candidate) => candidate.recordId === recordId && candidate.scope === selection.scope);
    if (!document || document.availability !== "XML_SUPPORTED" || document.validation !== "VALID" || !document.rows.some((row) => row.section === "Bilans") || !document.rows.some((row) => row.section === "RZiS")) {
      throw new Error("Pełne dane bilansu i RZiS z XML nie są dostępne dla wybranego raportu w tej organizacji.");
    }
    const previous = selected.get(recordId);
    if (previous) previous.years.push(year); else selected.set(recordId, { document, years: [year] });
  }
  const documents = [...selected.values()];
  const date = financialExcelDate(now), workbook = new ExcelJS.Workbook();
  workbook.creator = "SRM X-Ray"; workbook.created = now; workbook.title = `Dane finansowe ${selection.nip}`;
  addSheet(workbook, `ProfitLoss_${selection.nip}_${date}`, "RZiS", documents);
  addSheet(workbook, `Balance_${selection.nip}_${date}`, "Bilans", documents);
  if (selectedPeriods.some(p=>p.sourceRegistration)) registrySources(workbook.addWorksheet("Źródła"),selectedPeriods);
  qualitySheet(workbook,selectedPeriods);
  return { filename: `Financials_${selection.nip}_${date}.xlsx`, bytes: Buffer.from(await workbook.xlsx.writeBuffer()) };
}
