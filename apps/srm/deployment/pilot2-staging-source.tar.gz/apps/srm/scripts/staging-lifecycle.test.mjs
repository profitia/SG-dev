import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import {githubResponse, ReleaseDiagnosticError,createGithubRequester} from "./release-diagnostics.mjs";
import {
  runLifecycle,
  manifestFrom,
  releasePointer,
  createProvider,
} from "./staging-lifecycle.mjs";
import { contract } from "./staging-migrate.mjs";
import {
  digest,
  assertStagingDomainBinding,
  operations,
} from "../../../scripts/governance/srm-release-lifecycle.mjs";
import './staging-rollback.test.mjs';
const sha = "a".repeat(40);
const manifest = manifestFrom(
  {
    repositoryId: contract.repositoryId,
    approvedMainAncestor: true,
    ciPassed: true,
    developmentLiveSha: sha,
  },
  sha,
);
const approval = (mode = "onboard") => ({
  schemaVersion: "2.0",
  projectKey: "SRM",
  targetEnvironment: "staging",
  stagingDeploymentAuthorized: true,
  stagingMutationsAllowed: true,
  productionMutationsAllowed: false,
  manifest,
  releaseSha: sha,
  manifestDigest: digest(manifest),
  repository: contract.repository,
  repositoryId: contract.repositoryId,
  renderWorkspaceId: contract.render.workspaceId,
  renderProjectId: contract.render.projectId,
  renderEnvironmentId: contract.render.environmentId,
  neonProjectId: contract.neon.projectId,
  neonBranchId: contract.neon.branchId,
  neonEndpointId: contract.neon.endpointId,
  databaseName: "srm_app",
  approvalId: "synthetic-first",
  approvedBy: "synthetic",
  costOwner: "synthetic",
  costEvidence: {
    source: "PRIMARY_PROVIDER_QUOTE",
    url: "https://render.com/pricing",
    verifiedAt: new Date().toISOString(),
    monthlyComputeUsd: 7,
  },
  operations,
  expiresAt: new Date(Date.now() + 3600000).toISOString(),
  mode,
  firstOnboardingAuthorized: true,
  githubReviewerIds: [123],
  rollbackSchemaCompatible: true,
  budget: {
    renderPlan: contract.render.plan,
    renderInstances: 1,
    renderMonthlyComputeUsd: 7,
    neonMaxCu: 8,
    neonExistingEndpointOnly: true,
    providerEntitlementsAccepted: true,
    storageEgressBuildCostsAccepted: true,
    maxDeploymentAttempts: 3,
  },
});
function fixture() {
  let registry = JSON.parse(
      fs.readFileSync(
        new URL(
          "../../../Canon/registries/srm-environment-topology-v1.json",
          import.meta.url,
        ),
        "utf8",
      ),
    ),
    state = {
      schemaVersion: "1.0",
      projectKey: "SRM",
      targetEnvironment: "staging",
      generation: 0,
      release: null,
      baseline: null,
    },
    head = "0".repeat(40),
    counter = 0;
  // Explicit pre-onboarding fixture; canonical live Stage can now be ACTIVE.
  registry.environments.staging = {
  "status": "RESERVED",
  "activationStatus": "NOT_ONBOARDED",
  "github": {
    "environmentName": "srm-staging",
    "environmentId": null,
    "exclusiveProjectKey": "SRM",
    "status": "NOT_PROVISIONED"
  },
  "render": {
    "workspaceId": "tea-d7lps8rbc2fs73cn80dg",
    "projectId": "prj-dapbd3hsrm7s73es53fg",
    "environmentId": "evm-dapbdbbbc2fs73f4g7gg",
    "providerLabel": "Staging",
    "networkIsolation": "ENABLED",
    "services": {}
  },
  "neon": {
    "projectId": "snowy-breeze-40315151",
    "branchId": "br-broad-butterfly-b11t4v01",
    "branchName": "Staging",
    "parentBranchId": "br-nameless-bar-b1wlhjhx",
    "branchState": "ready",
    "branchProtected": false,
    "applicationDatabaseName": null,
    "applicationDatabaseStatus": "NOT_CREATED"
  },
  "domains": [],
  "deploymentPolicy": "NOT_ACTIVATED"
};
  const writes = [];
  let s = {
    source: "LIVE_PROVIDER_APIS",
    capturedAt: new Date().toISOString(),
    repository: { id: contract.repositoryId, full_name: contract.repository },
    renderProject: {
      id: contract.render.projectId,
      owner: { id: contract.render.workspaceId },
    },
    renderEnvironment: {
      id: contract.render.environmentId,
      projectId: contract.render.projectId,
      networkIsolationEnabled: true,
    },
    neonBranch: {
      id: contract.neon.branchId,
      project_id: contract.neon.projectId,
      name: "Staging",
      protected: false,
    },
    neonEndpoint: {
      id: contract.neon.endpointId,
      branch_id: contract.neon.branchId,
      host: contract.neon.directHost,
      autoscaling_limit_max_cu: 8,
    },
    databases: [],
    services: [],
    domains: [],
    liveDeploy: null,
    githubEnvironment: null,
  };
  const done = new Set();
  const p = {
    sourceProof: { source: "SYNTHETIC_ONLY", sha },
    store: {
      read: async () => ({
        head,
        state: structuredClone(state),
        registry: structuredClone(registry),
      }),
      commit: async ({ expectedHead, files }) => {
        assert.equal(expectedHead, head);
        if (files["Canon/registries/srm-staging-release-state-v1.json"])
          state = structuredClone(
            files["Canon/registries/srm-staging-release-state-v1.json"],
          );
        if (files["Canon/registries/srm-environment-topology-v1.json"])
          registry = structuredClone(
            files["Canon/registries/srm-environment-topology-v1.json"],
          );
        head = (++counter).toString(16).padStart(40, "0");
        return head;
      },
    },
    authority: async () => {},
    executorStopped: async () => false,
    snapshot: async () => ({
      ...structuredClone(s),
      capturedAt: new Date().toISOString(),
    }),
    preparationPreflight: async () => ({ source: "SYNTHETIC_ONLY" }),
    githubBindings: async () => {
      writes.push("github-bindings");
      done.add("github-bindings");
      return {};
    },
    githubEnvironment: async () => {
      writes.push("github-environment");
      s.githubEnvironment = { id: 1234, name: "srm-staging" };
      done.add("github-environment");
      return {};
    },
    pinSource: async () => {
      writes.push("release-pointer");
      done.add("release-pointer");
      return { pointer: releasePointer(sha) };
    },
    database: async () => {
      writes.push("database");
      s.databases = [
        {
          id: 4321,
          branch_id: contract.neon.branchId,
          name: "srm_app",
          owner_name: "neondb_owner",
        },
      ];
      done.add("database");
      return {};
    },
    schema: async () => {
      writes.push("schema");
      done.add("schema");
      return {};
    },
    service: async () => {
      writes.push("service");
      s.services = [
        {
          id: "srv-synthetic",
          name: "srm-staging-runtime",
          environmentId: contract.render.environmentId,
          branch: releasePointer(sha),
          autoDeployTrigger: "off",
          serviceDetails: { url: "https://synthetic.onrender.com" },
        },
      ];
      done.add("service");
      return {};
    },
    deploy: async () => {
      writes.push("deploy");
      s.liveDeploy = {
        id: "dep-synthetic",
        status: "live",
        commit: { id: sha },
      };
      done.add("deploy");
      return {};
    },
    rebind: async () => {
      writes.push("source-rebind");
      s.services[0].branch = "main";
      done.add("source-rebind");
      return {};
    },
    verify: async (_snapshot,expected=manifest) => {
      done.add("verify");
      return {
        source: "LIVE_RUNTIME_AND_SQL",
        sha: s.liveDeploy.commit.id,
        deployId: s.liveDeploy.id,
        serviceId: s.services[0].id,
        branchId: contract.neon.branchId,
        databaseId: 4321,
        githubEnvironmentId: 1234,
        domainBindings: assertStagingDomainBinding(s, contract),
        configuration: "PASS",
        githubProtection: "PASS",
        schema: "PASS",
        runtimeRole: "PASS",
        tenantIsolation: "PASS",
        health: "PASS",
        authentication: "PASS",
        persistence: "PASS",
        migrations: manifest.migrations,
        ...(expected.rollbackPlan?{artifact:{source:"OBSERVED_MEASURED_LKG_ALREADY_LIVE",liveDeployId:"dep-synthetic",physicalDigestRemeasuredAfterRollback:false,digest:expected.rollbackPlan.restorePoint.artifact.digest,algorithm:expected.rollbackPlan.restorePoint.artifact.algorithm,retainedDeployId:expected.rollbackPlan.restorePoint.deployId}}:{}),
      };
    },
    observe: async (op) => ({
      complete: done.has(op),
      result: { op },
      resources:
        op === "github-environment" && done.has(op)
          ? { githubEnvironmentId: 1234 }
          : op === "database" && done.has(op)
            ? { databaseId: 4321 }
            : op === "service" && done.has(op)
              ? { serviceId: "srv-synthetic" }
              : {},
    }),
  };
  return {
    p,
    writes,
    get state() {
      return state;
    },
    get registry() {
      return registry;
    },
    s,
    done,
  };
}
test("synthetic complete first onboarding publishes VERIFIED only after proof", async () => {
  const f = fixture();
  const r = await runLifecycle({
    authorization: approval(),
    manifest,
    provider: f.p,
    owner: "github-run:1",
  });
  assert.equal(r.status, "VERIFIED");
  assert.equal(f.registry.environments.staging.status, "ACTIVE");
  assert.equal(f.state.baseline.sha, sha);
  assert.deepEqual(f.writes, [
    "github-environment",
    "github-bindings",
    "release-pointer",
    "database",
    "schema",
    "service",
    "deploy",
    "source-rebind",
  ]);
});
for (const op of operations.filter((x) => x !== "reconcile"))
  test(
    "interruption/retry after " +
      op +
      " keeps first source and avoids duplicate writes",
    async () => {
      const f = fixture();
      await assert.rejects(
        runLifecycle({
          authorization: approval(),
          manifest,
          provider: f.p,
          owner: "github-run:1",
          stopAfter: op,
        }),
      );
      assert.equal(f.registry.environments.staging.status, "RESERVED");
      const before = f.writes.length;
      await runLifecycle({
        authorization: approval(),
        manifest,
        provider: f.p,
        owner: "github-run:1",
      });
      assert.equal(
        f.writes.filter((x) => x === op).length,
        op === "verify" ? 0 : 1,
      );
      assert.ok(f.writes.length >= before);
    },
  );
test("normal promotion and compatible code rollback share lifecycle", async () => {
  const f = fixture();
  await runLifecycle({
    authorization: approval(),
    manifest,
    provider: f.p,
    owner: "github-run:1",
  });
  const a = { ...approval("promote"), approvalId: "synthetic-second" };
  await runLifecycle({
    authorization: a,
    manifest,
    provider: f.p,
    owner: "github-run:2",
  });
  await runLifecycle({
    authorization: {
      ...approval("rollback"),
      approvalId: "synthetic-rollback",
      manifest:{...manifest,rollbackPlan:syntheticRestorePlan(manifest)},
      manifestDigest:digest({...manifest,rollbackPlan:syntheticRestorePlan(manifest)}),
    },
    manifest:{...manifest,rollbackPlan:syntheticRestorePlan(manifest)},
    provider: f.p,
    owner: "github-run:3",
  });
  assert.equal(f.writes.filter((x) => x === "service").length, 1);
});
const syntheticRestoreTime=new Date().toISOString();
function syntheticRestorePlan(m) {
  return {schemaVersion:'1.0',candidateSha:m.sha,schemaMigrations:m.migrations,restorePoint:{status:'VERIFIED',candidateSha:m.sha,sha:m.sha,serviceId:'srv-db496b3tqb8s73eh5sfg',deployId:'dep-synthetic',verifiedAt:syntheticRestoreTime,artifact:{sourceSha:m.sha,algorithm:'sha256-sorted-path-type-content-v1',digest:'a'.repeat(64),jobId:'job-synthetic'},configuration:{fingerprint:'b'.repeat(64),algorithm:'sha256-selected-service-config-and-sorted-resolved-env-pairs-v1',unchangedAfterMeasurement:true},database:{projectId:contract.neon.projectId,databaseName:'srm_app',sourceBranchId:contract.neon.branchId,recoveryBranchId:'br-backup',restoreRehearsalBranchId:'br-rehearsal',restoreRehearsalParentId:'br-backup',restoreRehearsalVerified:true,parentLsn:'0/ABCD',automaticSchemaOrDataRollbackAllowed:false,inventories:{migrations:m.migrations}}}};
}
test('rollback acknowledgement survives interruption in the fenced canonical INTENT',async()=>{
  const f=fixture();await runLifecycle({authorization:approval(),manifest,provider:f.p,owner:'github-run:1'});
  const m={...manifest,rollbackPlan:syntheticRestorePlan(manifest)};
  const a={...approval('rollback'),approvalId:'synthetic-durable-ack',manifest:m,manifestDigest:digest(m)};
  f.done.delete('deploy');f.done.delete('verify');
  let ack;
  f.p.deploy=async(s,approved,context)=>{
    ack={schemaVersion:'1.0',provider:'render-api',httpStatus:201,method:'POST',path:'/services/'+m.rollbackPlan.restorePoint.serviceId+'/rollback',serviceId:m.rollbackPlan.restorePoint.serviceId,requestBody:{deployId:m.rollbackPlan.restorePoint.deployId},deployId:'dep-rollback',sha:m.sha,measuredLkgArtifactDigest:m.rollbackPlan.restorePoint.artifact.digest,acceptedAt:new Date().toISOString()};
    await context.recordAcknowledgement(ack);
    throw Error('synthetic interruption after durable acknowledgement');
  };
  await assert.rejects(runLifecycle({authorization:a,manifest:m,provider:f.p,owner:'github-run:2'}));
  assert.ok(ack);
  assert.equal(f.state.release.steps.deploy.status,'INTENT');
  assert.deepEqual(f.state.release.steps.deploy.result.providerAcknowledgement,ack);
  assert.equal(f.state.release.steps.verify,undefined);
});
test("no authorization reaches any provider write or journal claim", async () => {
  const f = fixture();
  await assert.rejects(
    runLifecycle({
      authorization: { ...approval(), stagingMutationsAllowed: false },
      manifest,
      provider: f.p,
      owner: "x",
    }),
  );
  assert.equal(f.state.generation, 0);
  assert.equal(f.writes.length, 0);
});
test("actual wrong first deployed SHA blocks activation", async () => {
  const f = fixture();
  const deploy = f.p.deploy;
  f.p.deploy = async () => {
    const x = await deploy();
    f.s.liveDeploy.commit.id = "b".repeat(40);
    return x;
  };
  await assert.rejects(
    runLifecycle({
      authorization: approval(),
      manifest,
      provider: f.p,
      owner: "github-run:1",
    }),
  );
  assert.equal(f.registry.environments.staging.status, "RESERVED");
});
test("schema incompatibility blocks service creation", async () => {
  const f = fixture();
  f.p.schema = async () => {
    throw Error("checksum drift");
  };
  await assert.rejects(
    runLifecycle({
      authorization: approval(),
      manifest,
      provider: f.p,
      owner: "github-run:1",
    }),
  );
  assert.ok(!f.writes.includes("service"));
});
test("ambiguous accepted create is observed safely on retry", async () => {
  const f = fixture();
  const create = f.p.service;
  f.p.service = async () => {
    await create();
    throw Error("lost provider response");
  };
  await assert.rejects(
    runLifecycle({
      authorization: approval(),
      manifest,
      provider: f.p,
      owner: "github-run:1",
    }),
  );
  await runLifecycle({
    authorization: approval(),
    manifest,
    provider: f.p,
    owner: "github-run:1",
  });
  assert.equal(f.writes.filter((x) => x === "service").length, 1);
});
test("ambiguous absent create never retries blindly", async () => {
  const f = fixture();
  f.p.service = async () => {
    throw Error("network timeout");
  };
  await assert.rejects(
    runLifecycle({
      authorization: approval(),
      manifest,
      provider: f.p,
      owner: "github-run:1",
    }),
  );
  await assert.rejects(
    runLifecycle({
      authorization: approval(),
      manifest,
      provider: f.p,
      owner: "github-run:1",
    }),
    /Ambiguous provider/,
  );
  assert.equal(f.registry.environments.staging.status, "RESERVED");
});
test("incomplete live proof never activates target", async () => {
  const f = fixture();
  const verify = f.p.verify;
  f.p.verify = async () => ({ ...(await verify()), persistence: "PENDING" });
  await assert.rejects(
    runLifecycle({
      authorization: approval(),
      manifest,
      provider: f.p,
      owner: "github-run:1",
    }),
  );
  assert.equal(f.registry.environments.staging.status, "RESERVED");
});
test("wrong immutable provider identity rejects before write", async () => {
  const f = fixture();
  f.s.neonBranch.id = "br-nameless-bar-b1wlhjhx";
  await assert.rejects(
    runLifecycle({
      authorization: approval(),
      manifest,
      provider: f.p,
      owner: "github-run:1",
    }),
  );
  assert.equal(f.writes.length, 0);
});

import pg from "pg";
import { runMigrations, initializationConfig } from "./staging-migrate.mjs";
import {
  runPersistenceProbe,
  assertSchemaCatalog,
  renderServicePayload,
  verifyLifecycleSource,
  githubStore,
} from "./staging-lifecycle.mjs";
test("resume after lost final acknowledgement performs no further provider writes", async () => {
  const f = fixture();
  await runLifecycle({
    authorization: approval(),
    manifest,
    provider: f.p,
    owner: "github-run:1",
  });
  const n = f.writes.length;
  const result = await runLifecycle({
    authorization: approval(),
    manifest,
    provider: f.p,
    owner: "github-run:1",
  });
  assert.equal(result.recovered, true);
  assert.equal(f.writes.length, n);
});
test("concurrent promotion is rejected before provider mutation", async () => {
  const f = fixture();
  await assert.rejects(
    runLifecycle({
      authorization: approval(),
      manifest,
      provider: f.p,
      owner: "github-run:1",
      stopAfter: "database",
    }),
  );
  const n = f.writes.length;
  await assert.rejects(
    runLifecycle({
      authorization: { ...approval(), approvalId: "other" },
      manifest,
      provider: f.p,
      owner: "github-run:2",
    }),
    /Concurrent/,
  );
  assert.equal(f.writes.length, n);
});
test("baseline compare-and-swap conflict preserves RESERVED and observed live evidence", async () => {
  const f = fixture();
  const commit = f.p.store.commit;
  f.p.store.commit = async (x) => {
    if (x.files["Canon/registries/srm-environment-topology-v1.json"])
      throw Error("baseline conflict");
    return commit(x);
  };
  await assert.rejects(
    runLifecycle({
      authorization: approval(),
      manifest,
      provider: f.p,
      owner: "github-run:1",
    }),
    error => error.diagnostic.failureDomain === "RELEASE_BOOKKEEPING" &&
      error.diagnostic.applicationStatus === "LIVE_SOURCE_OBSERVED",
  );
  assert.equal(f.registry.environments.staging.status, "RESERVED");
  assert.equal(f.s.liveDeploy.commit.id, sha);
  f.p.store.commit = commit;
  await runLifecycle({
    authorization: approval(),
    manifest,
    provider: f.p,
    owner: "github-run:1",
  });
  assert.equal(f.writes.filter((x) => x === "deploy").length, 1);
});
test("drift after baseline publication never reports success", async () => {
  const f = fixture();
  const snapshot = f.p.snapshot;
  f.p.snapshot = async () => {
    const s = await snapshot();
    if (f.state.release?.phase === "VERIFIED")
      s.liveDeploy.commit.id = "c".repeat(40);
    return s;
  };
  await assert.rejects(
    runLifecycle({
      authorization: approval(),
      manifest,
      provider: f.p,
      owner: "github-run:1",
    }),
    /drift after publication/,
  );
});
test("normal promotion rejects stale baseline before any provider action", async () => {
  const f = fixture();
  await runLifecycle({
    authorization: approval(),
    manifest,
    provider: f.p,
    owner: "github-run:1",
  });
  f.s.liveDeploy.id = "dep-foreign";
  const n = f.writes.length;
  await assert.rejects(
    runLifecycle({
      authorization: { ...approval("promote"), approvalId: "new" },
      manifest,
      provider: f.p,
      owner: "github-run:2",
    }),
    /baseline drift/,
  );
  assert.equal(f.writes.length, n);
});
test("wrong canonical project blocks even with valid provider IDs", async () => {
  const f = fixture();
  const read = f.p.store.read;
  f.p.store.read = async () => {
    const x = await read();
    x.registry.environments.staging.neon.projectId = "sg2";
    return x;
  };
  await assert.rejects(
    runLifecycle({
      authorization: approval(),
      manifest,
      provider: f.p,
      owner: "github-run:1",
    }),
    /routing/,
  );
  assert.equal(f.writes.length, 0);
});
test("moving main cannot alter first creation payload source", () => {
  const p = renderServicePayload(manifest, {}, "approval");
  assert.equal(p.branch, "srm-release-" + sha);
  assert.equal(p.autoDeployTrigger, "off");
  assert.equal(p.environmentId, contract.render.environmentId);
  assert.equal(p.serviceDetails.runtime, "node");
  assert.equal(p.serviceDetails.numInstances, 1);
  assert.equal(p.serviceDetails.previews.generation, "off");
  assert.equal(
    p.serviceDetails.envSpecificDetails.buildCommand,
    contract.render.buildCommand,
  );
  assert.equal(
    p.envVars.find((x) => x.key === "SRM_RELEASE_OPERATION_ID").value,
    "approval",
  );
  assert.throws(() =>
    renderServicePayload({ ...manifest, sha: "main" }, {}, "approval"),
  );
});
test("source preflight permits moving main business code but rejects changed mechanism", () => {
  const calls = [];
  const git = (a) => {
    calls.push(a);
    if (a[0] === "remote")
      return { status: 0, stdout: "https://github.com/" + contract.repository };
    if (a[0] === "show")
      return {
        status: 0,
        stdout: JSON.stringify({
          ...contract,
          lifecycle: undefined,
          deploymentTimeGates: ["old-only"],
          github: { ...contract.github, soloOperatorApproval: undefined },
          existingDomainBinding: undefined,
        }),
      };
    return { status: 0, stdout: "" };
  };
  assert.equal(verifyLifecycleSource(sha, git), true);
  assert.ok(calls.some((x) => x[0] === "merge" && x[1] === "--ff-only"));
  assert.throws(
    () =>
      verifyLifecycleSource(sha, (a) =>
        a[0] === "diff" && a[2] === "HEAD" ? { status: 1, stdout: "" } : git(a),
      ),
    /mechanism changed/,
  );
  assert.throws(
    () =>
      verifyLifecycleSource(sha, (a) =>
        a[0] === "merge-base" ? { status: 1, stdout: "" } : git(a),
      ),
    /authority main/,
  );
});
test("changed approval policy invalidates the old release manifest authorization",async()=>{
  const oldContract=structuredClone(contract);delete oldContract.github.soloOperatorApproval;
  const oldManifest={...manifest,contractDigest:digest(oldContract)};
  const a={...approval("promote"),manifest:oldManifest,manifestDigest:digest(oldManifest)};
  const f=fixture();
  await assert.rejects(runLifecycle({authorization:a,manifest,provider:f.p,owner:"github-run:solo-test"}),/immutable manifest/);
  assert.equal(f.writes.length,0);
});
test("the live provider adapter accepts exact owner review and never changes existing GitHub protection",async()=>{
  const ge={id:23853126630,name:"srm-staging",protection_rules:[{type:"required_reviewers",prevent_self_review:false,reviewers:[{type:"User",reviewer:{id:275643368,login:"profitia"}}]}],deployment_branch_policy:{custom_branch_policies:true,protected_branches:false}};
  const calls=[];
  const provider=createProvider({SRM_RELEASE_GITHUB_TOKEN:"synthetic-only"},approval("promote"),manifest,"github-run:solo-test",async(url,options)=>{
    calls.push({url,method:options.method});
    return new Response(JSON.stringify(url.includes("deployment-branch-policies")?{total_count:1,branch_policies:[{name:"main",type:"branch"}]}:ge),{status:200});
  });
  assert.deepEqual(await provider.githubEnvironment({githubEnvironment:ge},approval("promote")),{protected:true});
  assert.ok(calls.length>0&&calls.every(x=>x.method==="GET"));
});
test("live provider adapter still rejects non-main deployment branch rules",async()=>{
  const ge={id:23853126630,name:"srm-staging",protection_rules:[{type:"required_reviewers",prevent_self_review:false,reviewers:[{type:"User",reviewer:{id:275643368,login:"profitia"}}]}],deployment_branch_policy:{custom_branch_policies:true,protected_branches:false}};
  const provider=createProvider({SRM_RELEASE_GITHUB_TOKEN:"synthetic-only"},approval("promote"),manifest,"github-run:solo-test",async(url)=>new Response(JSON.stringify(url.includes("deployment-branch-policies")?{total_count:1,branch_policies:[{name:"other",type:"branch"}]}:ge),{status:200}));
  await assert.rejects(provider.githubEnvironment({githubEnvironment:ge},approval("promote")),/Main-only/);
});
test("malformed protected authority evidence fails closed without writes", async () => {
  const calls = [];
  const store = githubStore(async (base, url, method = "GET") => {
    calls.push(method);
    return { protected: true, commit: { sha } };
  });
  await assert.rejects(store.read(), /Incomplete authority tree/);
  assert.deepEqual(calls, ["GET", "GET"]);
});
test(
  "real isolated Postgres persistence, idempotency and FORCE RLS catalog",
  { skip: !process.env.SRM_MIGRATION_TEST_URL },
  async () => {
    const u = new URL(process.env.SRM_MIGRATION_TEST_URL);
    assert.ok(
      ["127.0.0.1", "localhost"].includes(u.hostname) &&
        u.pathname === "/srm_migration_test",
      "Disposable localhost database required",
    );
    const c = new pg.Client({ connectionString: u.toString() });
    await c.connect();
    let runtime;
    try {
      await c.query("DROP SCHEMA IF EXISTS srm CASCADE");
      await c.query("DROP ROLE IF EXISTS srm_app_runtime");
      const initialize = initializationConfig({
        SRM_STAGING_ORGANIZATION_ID: "00000000-0000-4000-8000-000000000008",
        SRM_APP_DATABASE_PASSWORD: "isolated-local-probe-password-only-32plus",
      });
      await runMigrations(c, { initialize });
      await assertSchemaCatalog(c);
      const ru = new URL(u);
      ru.username = "srm_app_runtime";
      ru.password = initialize.password;
      runtime = new pg.Client({ connectionString: ru.toString() });
      await runtime.connect();
      await assert.rejects(
        runPersistenceProbe(runtime, initialize.organizationId, "probe", false),
        /Durable probe absent/,
      );
      const first = await runPersistenceProbe(
        runtime,
        initialize.organizationId,
        "probe",
        true,
      );
      const again = await runPersistenceProbe(
        runtime,
        initialize.organizationId,
        "probe",
        true,
      );
      assert.equal(first.recordId, again.recordId);
      assert.equal(
        (await runPersistenceProbe(runtime, initialize.organizationId, "probe"))
          .persisted,
        true,
      );
      await c.query(
        "ALTER TABLE srm.lookup_requests NO FORCE ROW LEVEL SECURITY",
      );
      await assert.rejects(assertSchemaCatalog(c), /FORCE RLS drift/);
      await c.query("ALTER TABLE srm.lookup_requests FORCE ROW LEVEL SECURITY");
      await assertSchemaCatalog(c);
    } finally {
      if (runtime) await runtime.end();
      await c.end();
    }
  },
);

import { deployRetryEvidence } from "./staging-lifecycle.mjs";
test("terminal provider failure permits bounded retry; ambiguous absence and budget exhaustion do not", () => {
  const a = approval(),
    failed = { id: "dep-failed", status: "build_failed", commit: { id: sha } };
  assert.equal(deployRetryEvidence([failed], manifest, a).recoverable, true);
  assert.equal(deployRetryEvidence([], manifest, a).recoverable, false);
  assert.equal(
    deployRetryEvidence([failed, failed, failed], manifest, a).canCreate,
    false,
  );
  assert.throws(
    () =>
      deployRetryEvidence(
        [{ status: "build_in_progress", commit: { id: "b".repeat(40) } }],
        manifest,
        a,
      ),
    /Concurrent foreign/,
  );
});
test("partial GitHub environment and failed schema action resume safely", async () => {
  const f = fixture();
  const action = f.p.schema;
  let attempts = 0;
  f.p.schema = async () => {
    if (++attempts === 1) throw Error("transaction rolled back");
    return action();
  };
  await assert.rejects(
    runLifecycle({
      authorization: approval(),
      manifest,
      provider: f.p,
      owner: "github-run:1",
    }),
  );
  await runLifecycle({
    authorization: approval(),
    manifest,
    provider: f.p,
    owner: "github-run:1",
  });
  assert.equal(attempts, 2);
  assert.equal(f.writes.filter((x) => x === "github-environment").length, 1);
});
test("automatic staging deployment is absent on push and pull request", () => {
  const y = fs.readFileSync(
    new URL("../../../.github/workflows/srm-ci.yml", import.meta.url),
    "utf8",
  );
  const blocks = y.split("  srm-staging-").slice(1);
  assert.equal(blocks.length, 2);
  for (const b of blocks)
    assert.ok(
      b.includes(
        "if: github.event_name == 'workflow_dispatch' && inputs.staging_deployment_authorized == 'YES'",
      ),
    );
  assert.equal(contract.render.autoDeployTrigger, "off");
});

import { assertLifecycleService } from "./staging-lifecycle.mjs";
test("service verification rejects unbudgeted scaling, disk and wrong name", () => {
  const c = contract.render;
  const s = {
    ownerId: c.workspaceId,
    environmentId: c.environmentId,
    repo: "https://github.com/" + contract.repository,
    autoDeployTrigger: "off",
    branch: "main",
    rootDir: c.rootDir,
    type: "web_service",
    name: c.serviceName,
    suspended: "not_suspended",
    serviceDetails: {
      region: c.region,
      plan: c.plan,
      runtime: "node",
      numInstances: 1,
      healthCheckPath: c.healthCheckPath,
      envSpecificDetails: {
        buildCommand: c.buildCommand,
        startCommand: c.startCommand,
      },
      previews: { generation: "off" },
    },
  };
  assert.equal(assertLifecycleService(s, manifest), true);
  for (const change of [
    { name: "foreign" },
    { serviceDetails: { ...s.serviceDetails, disk: { id: "disk-x" } } },
    { serviceDetails: { ...s.serviceDetails, autoscaling: { enabled: true } } },
    { suspended: "suspended" },
  ])
    assert.throws(() => assertLifecycleService({ ...s, ...change }, manifest));
});
test("missing source proof stops before the ownership publication", async () => {
  const f = fixture();
  delete f.p.sourceProof;
  await assert.rejects(
    runLifecycle({
      authorization: approval(),
      manifest,
      provider: f.p,
      owner: "github-run:1",
    }),
    /source evidence/,
  );
  assert.equal(f.state.generation, 0);
  assert.equal(f.writes.length, 0);
});

import { assertDeploymentInventory } from "./staging-lifecycle.mjs";
test("ambiguous or foreign inflight deployment blocks before any schema write", () => {
  assert.equal(assertDeploymentInventory([], sha), null);
  assert.equal(
    assertDeploymentInventory(
      [{ id: "live", status: "live", commit: { id: sha } }],
      sha,
    ).id,
    "live",
  );
  assert.throws(() =>
    assertDeploymentInventory([{ status: "live" }, { status: "live" }], sha),
  );
  for (const status of [
    "created",
    "queued",
    "build_in_progress",
    "pre_deploy_in_progress",
    "update_in_progress",
  ])
    assert.throws(() =>
      assertDeploymentInventory(
        [{ status, commit: { id: "b".repeat(40) } }],
        sha,
      ),
    );
});

import os from "node:os";
import { execFileSync, spawnSync } from "node:child_process";
import {
  publicationFiles,
  assertApprovedRuntimeUrl,
} from "./staging-lifecycle.mjs";
const journalPath = "Canon/registries/srm-staging-release-state-v1.json";
const registryPath = "Canon/registries/srm-environment-topology-v1.json";
test("runtime verification accepts only the explicitly approved Staging URL", () => {
  assert.doesNotThrow(() =>
    assertApprovedRuntimeUrl("https://srm-staging-runtime.onrender.com"),
  );
  for (const url of [
    "https://srm-development-runtime.onrender.com",
    "https://srm-staging-runtime-other.onrender.com",
    "http://srm-staging-runtime.onrender.com",
    "https://example.invalid",
    undefined,
  ])
    assert.throws(
      () => assertApprovedRuntimeUrl(url),
      /approved Staging runtime URL/,
    );
});
function publicationFixture({
  protectedMain = true,
  ciFailure = false,
  pending = false,
} = {}) {
  let head = "0".repeat(40),
    state = { schemaVersion: "1.0", generation: 0 },
    registry = { projectKey: "SRM" },
    candidateFiles = null,
    pr = null;
  const calls = [],
    blobs = new Map(),
    candidate = "1".repeat(40),
    merge = "2".repeat(40);
  let ref = null;
  const request = async (base, url, method = "GET", body) => {
    calls.push({ url, method, body });
    if (url.endsWith("/branches/main"))
      return { protected: protectedMain, commit: { sha: head } };
    if (url.includes("/git/trees/")) {
      const entries = [
        [journalPath, state],
        [registryPath, registry],
      ].map(([path, value]) => {
        const sha = digest(value);
        blobs.set(sha, value);
        return { path, sha, type: "blob" };
      });
      return { tree: entries, truncated: false };
    }
    if (url.includes("/git/blobs/"))
      return {
        content: Buffer.from(
          JSON.stringify(blobs.get(url.split("/").at(-1))),
        ).toString("base64"),
      };
    if (url === "/repos/profitia/SG-dev")
      return {
        id: contract.repositoryId,
        full_name: contract.repository,
        allow_merge_commit: true,
      };
    if (url.includes("/git/matching-refs/heads/")) return githubResponse(async()=>new Response(JSON.stringify(ref ? [{
      ...ref, ref: ref.ref ?? "refs/heads/"+url.split("/git/matching-refs/heads/")[1],
      object: {type:"commit", ...ref.object},
    }] : []),{status:200}),base+url,{method},'read-publication-branch');
    if (url.includes("/git/ref/heads/")) return ref && {
      ...ref,ref:ref.ref ?? "refs/heads/"+url.split("/git/ref/heads/")[1],
      object:{type:"commit",...ref.object},
    };
    if (url.endsWith("/git/refs") && method === "POST") {
      ref = { ref:body.ref, object: { type:"commit",sha: body.sha } };
      return githubResponse(async()=>new Response(JSON.stringify(ref),{status:201,headers:{'x-github-request-id':'ABCD:5678'}}),base+url,{method},'create-publication-branch');
    }
    if (url === "/graphql") {
      assert.equal(body.variables.input.expectedHeadOid, head);
      candidateFiles = Object.fromEntries(
        body.variables.input.fileChanges.additions.map((f) => [
          f.path,
          JSON.parse(Buffer.from(f.contents, "base64").toString()),
        ]),
      );
      if (!protectedMain) {
        state = candidateFiles[journalPath];
        head = candidate;
      } else ref = { ...ref,object: { type:"commit",sha: candidate } };
      return { data: { createCommitOnBranch: { commit: { oid: candidate } } } };
    }
    if (url.includes("/pulls?")) return pr ? [pr] : [];
    if (url.includes("/compare/"))
      return {
        status: "ahead",
        ahead_by: 1,
        base_commit: { sha: "0".repeat(40) },
        files: Object.keys(candidateFiles).map((filename) => ({
          filename,
          status: "modified",
        })),
      };
    if (url.includes("/contents/")) {
      const path = url.split("/contents/")[1].split("?")[0];
      return {
        encoding: "base64",
        content: Buffer.from(JSON.stringify(candidateFiles[path])).toString(
          "base64",
        ),
      };
    }
    if (url.endsWith("/pulls") && method === "POST") {
      pr = {
        number: 42,
        html_url: "https://github.com/profitia/SG-dev/pull/42",
        state: "open",
        head: { sha: candidate, repo: { id: contract.repositoryId } },
        base: { ref: "main" },
      };
      return pr;
    }
    if (url.includes("/check-runs?")) {
      if (fixture.onChecks) fixture.onChecks();
      return {
        total_count: fixture.pending ? 0 : 2,
        check_runs: fixture.pending
          ? []
          : ["srm-build", "governance"].map((name, i) => ({
              id: i + 1,
              name,
              head_sha: candidate,
              status: "completed",
              conclusion: ciFailure ? "failure" : "success",
            })),
      };
    }
    if (url.endsWith("/pulls/42/merge") && method === "PUT") {
      assert.equal(body.sha, candidate);
      assert.equal(body.merge_method, "merge");
      state = candidateFiles[journalPath];
      registry = candidateFiles[registryPath] ?? registry;
      head = merge;
      pr.merged_at = new Date().toISOString();
      return { merged: true, sha: merge };
    }
    throw Error("Unexpected provider fixture request: " + method + " " + url);
  };
  const fixture = {
    request,
    calls,
    pending,
    seedParentBranch() { ref = {object:{sha:head}}; },
    corruptBranch() { candidateFiles[journalPath] = {generation:999}; },
    get state() {
      return state;
    },
    get head() {
      return head;
    },
    moveMain() {
      head = "3".repeat(40);
    },
    changeJournal() {
      state = {
        ...state,
        generation: state.generation + 1,
        publicationNonce: "foreign",
      };
      head = "4".repeat(40);
    },
    changeRegistry() {
      registry = { ...registry, changed: true };
      head = "5".repeat(40);
    },
  };
  return fixture;
}
function acknowledgementFixture({failures=[],createdEffect=true,creationLost=false,transformRef=x=>x,storeOptions={}}={}) {
  const f=publicationFixture(); let created=false,reads=0,creates=0,time=100000;const pauses=[];
  const request=async(base,url,method,body,options)=>{
    if(method==='POST' && url.endsWith('/git/refs')) {
      creates++;
      created=true;
      const result=createdEffect ? await f.request(base,url,method,body) : null;
      if(creationLost) throw new ReleaseDiagnosticError({category:'NETWORK_TIMEOUT',requestReachedGitHub:'UNKNOWN',operation:'create-publication-branch'});
      return result;
    }
    if(created && url.includes('/git/ref/heads/')) {
      const failure=failures[reads++];
      if(failure) {
        if(failure.timeout) {time+=failure.elapsed??0;throw new ReleaseDiagnosticError({category:'NETWORK_TIMEOUT',requestReachedGitHub:'UNKNOWN'});}
        return githubResponse(async()=>new Response(JSON.stringify({message:failure.message??'Not Found',token:'secret-value'}),{
          status:failure.status,headers:{'x-github-request-id':'ABCD:1234',...failure.headers},
        }),base+url,{method:'GET'},'read-publication-branch',{missingIsError:true});
      }
      return transformRef(await f.request(base,url,method,body));
    }
    return f.request(base,url,method,body);
  };
  const store=githubStore(request,{...storeOptions,now:()=>time,pause:async ms=>{pauses.push(ms);time+=ms;}});
  return {f,store,pauses,advance(ms){time+=ms;},get reads(){return reads;},get creates(){return creates;}};
}
function resilientPublicationFixture({compareFailure=false,ackFailures=[],lostPr=false}={}) {
  const f=publicationFixture();let time=100000,created=false,failedCompare=false,failedPr=false;const events=[],pauses=[];
  const adapter=createGithubRequester(async(full,options)=>{
    const url=full.slice('https://api.github.com'.length),method=options.method;
    if(compareFailure && url.includes('/compare/') && !failedCompare){failedCompare=true;return new Response('{}',{status:502});}
    if(created && url.includes('/git/ref/heads/') && ackFailures.length){
      const status=ackFailures.shift();return new Response('{}',{status,headers:{'x-poll-interval':'300'}});
    }
    const result=await f.request('https://api.github.com',url,method,options.body ? JSON.parse(options.body) : undefined);
    if(method==='POST' && url.endsWith('/git/refs'))created=true;
    if(lostPr && method==='POST' && url.endsWith('/pulls') && !failedPr){failedPr=true;return new Response('{}',{status:502});}
    return new Response(JSON.stringify(result??{message:'Not Found'}),{status:result===null ? 404 : method==='POST' && url.endsWith('/git/refs') ? 201 : 200});
  },{authorizationExpiresAt:new Date(time+3600000).toISOString(),now:()=>time,pause:async ms=>{pauses.push(ms);time+=ms;},random:()=>0,emit:d=>events.push(d)});
  const store=githubStore((base,url,method='GET',body,options)=>adapter(base+url,{method,body:body ? JSON.stringify(body) : undefined},url==='/graphql' ? 'createCommitOnBranch' : 'github-rest',options),{
    now:()=>time,pause:async ms=>{pauses.push(ms);time+=ms;},authorizationExpiresAt:new Date(time+3600000).toISOString(),
  });return {f,store,pauses,events};
}
test('adapter read 502 recovery preserves branch, candidate, PR and journal identity',async()=>{
  const x=resilientPublicationFixture({compareFailure:true});await x.store.commit(publicationInput(await x.store.read()));
  assert.equal(x.f.state.generation,1);assert.equal(x.events.at(-1).retryDecision,'RECOVERED');assert.equal(x.events.at(-1).endpoint,'publication-compare');
  for(const ending of ['/git/refs','/pulls'])assert.equal(x.f.calls.filter(c=>c.method==='POST'&&c.url.endsWith(ending)).length,1);
  assert.equal(x.f.calls.filter(c=>c.url==='/graphql').length,1);
});
test('adapter never nests retries inside acknowledged creation observation',async()=>{
  const x=resilientPublicationFixture({ackFailures:[404,502]});await x.store.commit(publicationInput(await x.store.read()));
  assert.deepEqual(x.pauses,[300000,300000]);assert.deepEqual(x.events,[]);assert.equal(x.f.state.generation,1);
  assert.equal(x.f.calls.filter(c=>c.method==='POST'&&c.url.endsWith('/git/refs')).length,1);
});
test('ambiguous PR write 502 stops, then independently reconciles without a duplicate publication',async()=>{
  const x=resilientPublicationFixture({lostPr:true}),input=publicationInput(await x.store.read());
  await assert.rejects(x.store.commit(input),e=>e.diagnostic.httpMethod==='POST'&&e.diagnostic.endpoint==='publication-prs'&&e.diagnostic.retryDecision==='STOP_AMBIGUOUS_WRITE');
  assert.equal(x.f.state.generation,0);assert.deepEqual(x.pauses,[]);await x.store.commit(input);
  assert.equal(x.f.state.generation,1);assert.equal(x.f.calls.filter(c=>c.method==='POST'&&c.url.endsWith('/pulls')).length,1);
  assert.equal(x.f.calls.filter(c=>c.method==='POST'&&c.url.endsWith('/git/refs')).length,1);assert.equal(x.f.calls.filter(c=>c.url==='/graphql').length,1);
});
const publicationInput=current=>({expectedHead:current.head,files:{[journalPath]:{...current.state,generation:1}},message:'acknowledgement test'});
test('created branch immediate exact GET publishes once without backoff',async()=>{
  const x=acknowledgementFixture();await x.store.commit(publicationInput(await x.store.read()));
  assert.equal(x.reads,1);assert.deepEqual(x.pauses,[]);
  assert.equal(x.f.calls.filter(c=>c.method==='POST' && c.url.endsWith('/git/refs')).length,1);
  assert.equal(x.f.calls.filter(c=>c.url==='/graphql').length,1);
});
test('acknowledged creation recovers a typed transient 404 by GET only',async()=>{
  const x=acknowledgementFixture({failures:[{status:404}]});await x.store.commit(publicationInput(await x.store.read()));
  assert.equal(x.reads,2);assert.deepEqual(x.pauses,[250]);assert.equal(x.f.state.generation,1);
  assert.equal(x.f.calls.filter(c=>c.method==='POST' && c.url.endsWith('/git/refs')).length,1);
  assert.equal(x.f.calls.filter(c=>c.url==='/graphql').length,1);
});
test('five typed 404 acknowledgements stop with actual evidence and no commit',async()=>{
  const x=acknowledgementFixture({failures:Array.from({length:5},()=>({status:404}))});
  await assert.rejects(x.store.commit(publicationInput(await x.store.read())),e=>{
    assert.equal(e.diagnostic.httpStatus,404);assert.equal(e.diagnostic.requestId,'ABCD:1234');
    assert.equal(e.diagnostic.stage,'publication-branch-acknowledgement');assert.equal(e.diagnostic.operation,'verify-publication-branch');
    assert.equal(e.diagnostic.attemptNumber,5);assert.equal(e.diagnostic.attemptLimit,5);
    assert.equal(e.diagnostic.retryDecision,'STOP_ATTEMPT_LIMIT');assert.equal(e.diagnostic.providerEffectObserved,'CREATION_ACKNOWLEDGED');return true;
  });
  assert.equal(x.reads,5);assert.deepEqual(x.pauses,[250,500,1000,2000]);assert.equal(x.f.state.generation,0);
  assert.equal(x.f.calls.filter(c=>c.method==='POST').length,1);assert.ok(!x.f.calls.some(c=>c.url==='/graphql'));
});
for(const status of [401,403]) test('explicit authentication/permission rejection never retries GET: '+status,async()=>{
  const x=acknowledgementFixture({failures:[{status,message:status===401?'Bad credentials':'Resource not accessible by integration'}]});
  await assert.rejects(x.store.commit(publicationInput(await x.store.read())),e=>{
    assert.equal(e.diagnostic.httpStatus,status);assert.equal(e.diagnostic.retryDecision,'STOP_NOT_RETRYABLE');return true;
  });
  assert.equal(x.reads,1);assert.deepEqual(x.pauses,[]);assert.ok(!x.f.calls.some(c=>c.url==='/graphql'));
});
for(const failure of [
  {status:429,headers:{'retry-after':'1'},wait:1000},
  {status:503,headers:{'retry-after':'2','x-poll-interval':'3'},wait:3000},
  {status:403,message:'API rate limit exceeded',headers:{'x-ratelimit-remaining':'0','x-ratelimit-reset':'102'},wait:2000},
  {timeout:true,wait:250},
]) test('GET acknowledgement honors bounded retry guidance: '+JSON.stringify(failure),async()=>{
  const x=acknowledgementFixture({failures:[failure]});await x.store.commit(publicationInput(await x.store.read()));
  assert.deepEqual(x.pauses,[failure.wait]);assert.equal(x.reads,2);assert.equal(x.f.calls.filter(c=>c.url==='/graphql').length,1);
});
for(const failure of [
  {status:429,decision:'STOP_TIME_LIMIT'},
  {status:429,headers:{'retry-after':'60'},decision:'STOP_TIME_LIMIT'},
  {status:429,headers:{'retry-after':'invalid'},decision:'STOP_RETRY_GUIDANCE'},
  {status:403,message:'API rate limit exceeded',headers:{'x-ratelimit-remaining':'0'},decision:'STOP_RETRY_GUIDANCE'},
  {status:404,headers:{'x-ratelimit-remaining':'0','x-ratelimit-reset':'160'},decision:'STOP_TIME_LIMIT'},
]) test('required retry delay outside budget or invalid guidance fails closed: '+JSON.stringify(failure),async()=>{
  const x=acknowledgementFixture({failures:[failure],storeOptions:{acknowledgementTimeoutMs:10000}});await assert.rejects(x.store.commit(publicationInput(await x.store.read())),e=>{
    assert.equal(e.diagnostic.retryDecision,failure.decision);return true;
  });assert.equal(x.reads,1);assert.deepEqual(x.pauses,[]);assert.ok(!x.f.calls.some(c=>c.url==='/graphql'));
});
test('elapsed acknowledgement deadline prohibits another GET',async()=>{
  const x=acknowledgementFixture({failures:[{timeout:true,elapsed:10000}],storeOptions:{acknowledgementTimeoutMs:10000}});
  await assert.rejects(x.store.commit(publicationInput(await x.store.read())),e=>{assert.equal(e.diagnostic.retryDecision,'STOP_TIME_LIMIT');return true;});
  assert.equal(x.reads,1);assert.deepEqual(x.pauses,[]);
});
test('validated 201 then transient 404 respects GitHub 300-second polling and publishes exactly once',async()=>{
  const x=acknowledgementFixture({failures:[{status:404,headers:{'x-poll-interval':'300'}},{status:404,headers:{'x-poll-interval':'300'}}]});
  await x.store.commit(publicationInput(await x.store.read()));
  assert.deepEqual(x.pauses,[300000,300000]);assert.equal(x.reads,3);assert.equal(x.creates,1);
  assert.equal(x.f.state.generation,1);assert.equal(x.f.calls.filter(c=>c.url==='/graphql').length,1);
  assert.equal(x.f.calls.filter(c=>c.method==='POST' && c.url.endsWith('/pulls')).length,1);
});
test('mandatory delay outside configured acknowledgement bound preserves resumable parent branch',async()=>{
  const x=acknowledgementFixture({failures:[{status:404,headers:{'x-poll-interval':'300'}}],storeOptions:{acknowledgementTimeoutMs:10000}});
  await assert.rejects(x.store.commit(publicationInput(await x.store.read())),e=>{
    assert.equal(e.diagnostic.creationHttpStatus,201);assert.equal(e.diagnostic.creationRequestId,'ABCD:5678');
    assert.equal(e.diagnostic.retryDecision,'STOP_TIME_LIMIT');assert.equal(e.diagnostic.retryNotBeforeAt,400000);
    assert.equal(e.diagnostic.acknowledgementDeadlineAt,110000);return true;
  });
  assert.deepEqual(x.pauses,[]);assert.equal(x.creates,1);assert.equal(x.f.state.generation,0);
  x.advance(300000);
  await x.store.commit(publicationInput(await x.store.read()));
  assert.equal(x.creates,1);assert.equal(x.f.state.generation,1);
});
test('retry cannot extend release authorization even when acknowledgement budget remains',async()=>{
  const x=acknowledgementFixture({failures:[{status:404,headers:{'x-poll-interval':'300'}}],storeOptions:{authorizationExpiresAt:new Date(200000).toISOString()}});
  await assert.rejects(x.store.commit(publicationInput(await x.store.read())),e=>{
    assert.equal(e.diagnostic.retryDecision,'STOP_AUTHORIZATION_WINDOW');assert.equal(e.diagnostic.acknowledgementDeadlineAt,200000);return true;
  });
  assert.deepEqual(x.pauses,[]);assert.equal(x.creates,1);assert.ok(!x.f.calls.some(c=>c.url==='/graphql'));
});
test('authorization expiring during observation prohibits a publication commit',async()=>{
  let x; x=acknowledgementFixture({transformRef:r=>{x.advance(1000);return r;},storeOptions:{authorizationExpiresAt:new Date(100500).toISOString()}});
  await assert.rejects(x.store.commit(publicationInput(await x.store.read())),e=>e.diagnostic.retryDecision==='STOP_AUTHORIZATION_EXPIRED');
  assert.equal(x.creates,1);assert.ok(!x.f.calls.some(c=>c.url==='/graphql'));
});
test('authorization expiring during protected CI prohibits merge and preserves the existing PR',async()=>{
  const x=acknowledgementFixture({storeOptions:{authorizationExpiresAt:new Date(100500).toISOString()}});
  x.f.onChecks=()=>x.advance(1000);
  await assert.rejects(x.store.commit(publicationInput(await x.store.read())),e=>e.diagnostic.retryDecision==='STOP_AUTHORIZATION_EXPIRED');
  assert.equal(x.f.calls.filter(c=>c.method==='POST' && c.url.endsWith('/pulls')).length,1);
  assert.ok(!x.f.calls.some(c=>c.url.endsWith('/merge')));assert.equal(x.f.state.generation,0);
});
test('expired release cannot create a publication branch',async()=>{
  const x=acknowledgementFixture({storeOptions:{authorizationExpiresAt:new Date(100000).toISOString()}});
  await assert.rejects(x.store.commit(publicationInput(await x.store.read())),e=>e.diagnostic.retryDecision==='STOP_AUTHORIZATION_EXPIRED');
  assert.equal(x.creates,0);assert.ok(!x.f.calls.some(c=>c.method==='POST'));
});
test('acknowledgement configuration rejects unbounded, invalid or excessive limits',()=>{
  for(const options of [{acknowledgementTimeoutMs:0},{acknowledgementTimeoutMs:1800001},{acknowledgementTimeoutMs:Infinity},{acknowledgementAttemptLimit:6},{acknowledgementAttemptLimit:0},{authorizationExpiresAt:'invalid'}])
    assert.throws(()=>githubStore(()=>{},options));
});
for(const status of [200,202])test('an exact creation body without HTTP 201 never authorizes recovery: '+status,async()=>{
  const f=publicationFixture(); const store=githubStore(async(base,url,method,body)=>{
    const result=await f.request(base,url,method,body);
    return method==='POST' && url.endsWith('/git/refs') ? githubResponse(async()=>new Response(JSON.stringify(result),{status}),base+url,{method},'create-publication-branch') : result;
  });
  await assert.rejects(store.commit(publicationInput(await store.read())),/Publication branch acknowledgement unavailable/);
  assert.ok(!f.calls.some(c=>c.url==='/graphql'));assert.equal(f.calls.filter(c=>c.method==='POST').length,1);
});
test('lost create acknowledgement resumes the observed parent without creating another branch',async()=>{
  const x=acknowledgementFixture({creationLost:true});const input=publicationInput(await x.store.read());
  await assert.rejects(x.store.commit(input),e=>e.diagnostic.retryDecision==='STOP_AMBIGUOUS_CREATE');
  await x.store.commit(input);
  assert.equal(x.creates,1);assert.equal(x.f.calls.filter(c=>c.url==='/graphql').length,1);assert.equal(x.f.state.generation,1);
});
test('lost PR acknowledgement resumes exact existing candidate and PR without duplicate writes',async()=>{
  const f=publicationFixture();let lost=false;
  const store=githubStore(async(base,url,method,body)=>{
    const result=await f.request(base,url,method,body);
    if(method==='POST' && url.endsWith('/pulls') && !lost){lost=true;throw new ReleaseDiagnosticError({category:'NETWORK_TIMEOUT',requestReachedGitHub:'UNKNOWN'});}
    return result;
  });const input=publicationInput(await store.read());await assert.rejects(store.commit(input));await store.commit(input);
  assert.equal(f.calls.filter(c=>c.method==='POST' && c.url.endsWith('/git/refs')).length,1);
  assert.equal(f.calls.filter(c=>c.url==='/graphql').length,1);assert.equal(f.calls.filter(c=>c.method==='POST' && c.url.endsWith('/pulls')).length,1);
  assert.equal(f.state.generation,1);
});
for(const transformRef of [r=>({...r,object:{...r.object,sha:'9'.repeat(40)}}),r=>({...r,ref:'refs/heads/foreign'})])
test('created branch identity/SHA conflict never advances or overwrites',async()=>{
  const x=acknowledgementFixture({transformRef});await assert.rejects(x.store.commit(publicationInput(await x.store.read())),e=>{
    assert.equal(e.diagnostic.category,'REF_CONFLICT');assert.equal(e.diagnostic.retryDecision,'STOP_IDENTITY_CONFLICT');return true;
  });assert.equal(x.reads,1);assert.deepEqual(x.pauses,[]);assert.ok(!x.f.calls.some(c=>c.url==='/graphql' || c.method==='PATCH' || c.method==='DELETE'));
});
for(const createdEffect of [false,true]) test('lost create acknowledgement is observed once and never retried: '+createdEffect,async()=>{
  const x=acknowledgementFixture({creationLost:true,createdEffect});await assert.rejects(x.store.commit(publicationInput(await x.store.read())),e=>{
    assert.equal(e.diagnostic.retryDecision,'STOP_AMBIGUOUS_CREATE');assert.equal(e.diagnostic.providerEffectObserved,createdEffect?'BRANCH_AT_EXPECTED_PARENT':'NOT_OBSERVED');return true;
  });assert.equal(x.reads,1);assert.equal(x.creates,1);assert.deepEqual(x.pauses,[]);assert.ok(!x.f.calls.some(c=>c.url==='/graphql'));
});
test('existing publication branch with invalid identity cannot trigger creation or a commit',async()=>{
  const f=publicationFixture();f.seedParentBranch();
  const store=githubStore(async(base,url,method,body)=>{
    const result=await f.request(base,url,method,body);
    return url.includes('/git/matching-refs/heads/') ? result.map(ref=>({...ref,ref:'refs/heads/foreign'})) : result;
  });
  await assert.rejects(store.commit(publicationInput(await store.read())),/Publication branch acknowledgement unavailable/);
  assert.ok(!f.calls.some(c=>c.method==='POST' || c.url==='/graphql'));assert.equal(f.state.generation,0);
});
test('invalid creation acknowledgement fails without retrying any write or read',async()=>{
  const f=publicationFixture();let created=false,postCreateReads=0;
  const store=githubStore(async(base,url,method,body)=>{
    if(created && url.includes('/git/ref/heads/'))postCreateReads++;
    const result=await f.request(base,url,method,body);
    if(method==='POST' && url.endsWith('/git/refs')){created=true;return {...result,ref:'refs/heads/foreign'};}
    return result;
  });
  await assert.rejects(store.commit(publicationInput(await store.read())),/Publication branch acknowledgement unavailable/);
  assert.equal(postCreateReads,0);assert.equal(f.calls.filter(c=>c.method==='POST').length,1);assert.ok(!f.calls.some(c=>c.url==='/graphql'));
});
test("branch created with only the parent resumes the missing publication commit once", async () => {
  const f=publicationFixture(); f.seedParentBranch(); const store=githubStore(f.request), current=await store.read();
  await store.commit({expectedHead:current.head,files:{[journalPath]:{...current.state,generation:1}},message:"intent"});
  assert.equal(f.state.generation,1);
  assert.equal(f.calls.filter(x=>x.url==="/graphql").length,1);
  assert.equal(f.calls.filter(x=>x.url.endsWith("/git/refs") && x.method==="POST").length,0);
});
test("missing branch acknowledgement retains the exact failure gate and never writes a commit", async () => {
  const f=publicationFixture(); let created=false;
  const store=githubStore(async(base,url,method,body)=>{
    const result=await f.request(base,url,method,body);
    if(url.endsWith('/git/refs') && method==='POST') created=true;
    if(created && url.includes('/git/ref/heads/')) return null;
    return result;
  });
  const current=await store.read();
  await assert.rejects(store.commit({expectedHead:current.head,files:{[journalPath]:{...current.state,generation:1}},message:'intent'}),e=>{
    assert.equal(e.diagnostic.stage,'publication-branch-acknowledgement');
    assert.equal(e.diagnostic.operation,'verify-publication-branch');
    assert.equal(e.diagnostic.message,'Publication branch acknowledgement unavailable');
    assert.match(e.diagnostic.branch,/^srm-publication-[a-f0-9]{24}$/);
    assert.equal(e.diagnostic.expectedSha,current.head); assert.equal(e.diagnostic.generation,1);
    assert.equal(e.diagnostic.effect,'OBSERVATION_REQUIRED'); return true;
  });
  assert.equal(f.state.generation,0);
  assert.equal(f.calls.filter(x=>x.url.endsWith('/git/refs') && x.method==='POST').length,1);
  assert.ok(!f.calls.some(x=>x.url==='/graphql' || x.url.endsWith('/merge')));
});
for(const phase of ['repository','branch-read','branch-create','branch-acknowledgement']) test('pre-commit '+phase+' failure identifies its boundary without exposing exception contents',async()=>{
  const f=publicationFixture();let created=false;
  const store=githubStore(async(base,url,method,body)=>{
    if((phase==='repository' && url==='/repos/profitia/SG-dev') ||
      (phase==='branch-read' && url.includes('/git/matching-refs/heads/')) ||
      (phase==='branch-create' && method==='POST' && url.endsWith('/git/refs')) ||
      (phase==='branch-acknowledgement' && created && url.includes('/git/ref/heads/'))) throw Error('token=private postgresql://secret');
    const result=await f.request(base,url,method,body);
    if(method==='POST' && url.endsWith('/git/refs'))created=true;
    return result;
  });
  const current=await store.read();
  await assert.rejects(store.commit({expectedHead:current.head,files:{[journalPath]:{...current.state,generation:1}},message:'intent'}),e=>{
    assert.equal(e.diagnostic.stage,'publication-'+phase); assert.match(e.diagnostic.branch,/^srm-publication-[a-f0-9]{24}$/);
    assert.equal(e.diagnostic.expectedSha,current.head); assert.equal(e.diagnostic.generation,1);
    assert.ok(!JSON.stringify(e.diagnostic).match(/private|postgresql|secret/));return true;
  });
  assert.equal(f.state.generation,0); assert.ok(!f.calls.some(x=>x.url==='/graphql' || x.url.endsWith('/merge')));
});
test('repository policy rejection reports a static safe reason before branch creation',async()=>{
  const f=publicationFixture(),store=githubStore((base,url,method,body)=>url==='/repos/profitia/SG-dev' ? {id:contract.repositoryId,full_name:contract.repository,allow_merge_commit:false} : f.request(base,url,method,body));
  const current=await store.read();
  await assert.rejects(store.commit({expectedHead:current.head,files:{[journalPath]:{...current.state,generation:1}},message:'intent'}),e=>{
    assert.equal(e.diagnostic.stage,'publication-repository'); assert.equal(e.diagnostic.message,'Lawful merge publication unavailable');return true;
  });
  assert.ok(!f.calls.some(x=>x.method==='POST'));assert.equal(f.state.generation,0);
});
test("structured GraphQL rejection preserves diagnostics, parent branch and journal", async () => {
  const f=publicationFixture();
  const store=githubStore((base,url,method,body)=>url==="/graphql" ? Promise.resolve({errors:[{type:"FORBIDDEN",path:["createCommitOnBranch"],message:"Resource not accessible by integration secret-token"}]}) : f.request(base,url,method,body));
  const current=await store.read();
  await assert.rejects(store.commit({expectedHead:current.head,files:{[journalPath]:{...current.state,generation:1}},message:"intent"}),e=>{
    assert.equal(e.diagnostic.category,"GRAPHQL_REJECTION");assert.equal(e.diagnostic.effect,"NO_COMMIT_OBSERVED");
    assert.equal(e.diagnostic.observedSha,current.head);assert.equal(e.diagnostic.generation,1);
    assert.equal(e.diagnostic.graphqlErrors[0].type,"FORBIDDEN");assert.ok(!JSON.stringify(e.diagnostic).includes("secret-token"));return true;
  });
  assert.equal(f.state.generation,0);assert.ok(!f.calls.some(x=>x.url.endsWith("/merge")));
});
for(const accepted of [false,true]) test("lost commit response is observed and never blindly retried: accepted="+accepted,async()=>{
  const f=publicationFixture();let writes=0,lose=true;
  const store=githubStore(async(base,url,method,body)=>{
    if(url==="/graphql") {writes++; if(accepted || !lose) {const result=await f.request(base,url,method,body);if(!lose)return result;}
      if(lose){lose=false;const {ReleaseDiagnosticError}=await import('./release-diagnostics.mjs');throw new ReleaseDiagnosticError({category:"NETWORK_TIMEOUT",requestReachedGitHub:"UNKNOWN",operation:"createCommitOnBranch"});}}
    return f.request(base,url,method,body);
  });
  const current=await store.read(),input={expectedHead:current.head,files:{[journalPath]:{...current.state,generation:1}},message:"intent"};
  await assert.rejects(store.commit(input),e=>{assert.equal(e.diagnostic.effect,accepted ? "COMMIT_OBSERVED":"NO_COMMIT_OBSERVED");return true;});
  assert.equal(writes,1);assert.equal(f.state.generation,0);
  await store.commit(input);assert.equal(f.state.generation,1);assert.equal(writes,accepted?1:2);
});
test("conflicting existing publication commit refuses retry without any second write",async()=>{
  const f=publicationFixture({pending:true});let time=0;
  const store=githubStore(f.request,{now:()=>time,pause:async()=>{time++;},checkTimeoutMs:1});
  const current=await store.read(),input={expectedHead:current.head,files:{[journalPath]:{...current.state,generation:1}},message:"intent"};
  await assert.rejects(store.commit(input));f.corruptBranch();f.pending=false;
  await assert.rejects(store.commit(input),/Publication branch content drift/);
  assert.equal(f.calls.filter(x=>x.url==="/graphql").length,1);assert.equal(f.state.generation,0);
});
test("protected main publishes a fenced journal through a checked PR without protection writes", async () => {
  const f = publicationFixture(),
    store = githubStore(f.request),
    current = await store.read();
  await store.commit({
    expectedHead: current.head,
    files: { [journalPath]: { ...current.state, generation: 1 } },
    message: "test release intent",
  });
  assert.equal(f.state.generation, 1);
  assert.match(f.state.publicationNonce, /^[a-f0-9]{64}$/);
  assert.ok(f.calls.some((x) => x.url.endsWith("/pulls/42/merge")));
  assert.ok(
    !f.calls.some(
      (x) => /protection|rulesets/.test(x.url) && x.method !== "GET",
    ),
  );
  assert.ok(
    f.calls
      .filter((x) => x.url === "/graphql")
      .every((x) =>
        x.body.variables.input.branch.branchName.startsWith("srm-publication-"),
      ),
  );
});
test("protected publication preserves unrelated movement of main", async () => {
  const f = publicationFixture(),
    store = githubStore(f.request),
    current = await store.read();
  f.onChecks = () => f.moveMain();
  await store.commit({
    expectedHead: current.head,
    files: { [journalPath]: { ...current.state, generation: 1 } },
    message: "intent",
  });
  assert.equal(f.state.generation, 1);
});
for (const mutation of ["changeJournal", "changeRegistry"])
  test("protected publication refuses concurrent " + mutation, async () => {
    const f = publicationFixture(),
      store = githubStore(f.request),
      current = await store.read();
    f.onChecks = () => f[mutation]();
    await assert.rejects(
      store.commit({
        expectedHead: current.head,
        files: { [journalPath]: { ...current.state, generation: 1 } },
        message: "intent",
      }),
      /publication conflict/,
    );
    assert.ok(!f.calls.some((x) => x.url.endsWith("/merge")));
  });
test("failed publication CI keeps its PR and never merges", async () => {
  const f = publicationFixture({ ciFailure: true }),
    store = githubStore(f.request),
    current = await store.read();
  await assert.rejects(
    store.commit({
      expectedHead: current.head,
      files: { [journalPath]: { ...current.state, generation: 1 } },
      message: "intent",
    }),
    /CI failed/,
  );
  assert.equal(f.state.generation, 0);
  assert.ok(!f.calls.some((x) => x.url.endsWith("/merge")));
});
test("pending publication CI times out with the PR preserved", async () => {
  let time = 0;
  const f = publicationFixture({ pending: true });
  const store = githubStore(f.request, {
    now: () => time,
    pause: async () => {
      time++;
    },
    checkTimeoutMs: 2,
  });
  const current = await store.read();
  await assert.rejects(
    store.commit({
      expectedHead: current.head,
      files: { [journalPath]: { ...current.state, generation: 1 } },
      message: "intent",
    }),
    /CI pending/,
  );
  assert.equal(f.state.generation, 0);
  assert.ok(
    f.calls.some((x) => x.url.endsWith("/pulls") && x.method === "POST"),
  );
  f.pending = false;
  await store.commit({
    expectedHead: current.head,
    files: { [journalPath]: { ...current.state, generation: 1 } },
    message: "intent",
  });
  assert.equal(f.state.generation, 1);
  assert.equal(
    f.calls.filter((x) => x.url.endsWith("/pulls") && x.method === "POST")
      .length,
    1,
  );
  assert.equal(f.calls.filter((x) => x.url === "/graphql").length, 1);
});
test("unprotected publication retains exact expected-head CAS", async () => {
  const f = publicationFixture({ protectedMain: false }),
    store = githubStore(f.request),
    current = await store.read();
  f.moveMain();
  await assert.rejects(
    store.commit({
      expectedHead: current.head,
      files: { [journalPath]: { ...current.state, generation: 1 } },
      message: "intent",
    }),
    /Baseline update conflict/,
  );
  assert.ok(f.calls.every((x) => x.method === "GET"));
});
test("publication rejects missing journal, skipped generation and unrelated files", async () => {
  const f = publicationFixture(),
    store = githubStore(f.request),
    current = await store.read();
  for (const files of [
    { [registryPath]: {} },
    { [journalPath]: { generation: 2 } },
    { "apps/srm/src/business.ts": {} },
  ])
    await assert.rejects(
      store.commit({ expectedHead: current.head, files, message: "intent" }),
    );
  assert.ok(f.calls.every((x) => x.method === "GET"));
});
test("real Git three-way merge rejects racing journal proposals and preserves unrelated development", () => {
  const dir = fs.mkdtempSync(os.tmpdir() + "/srm-publication-git-");
  const git = (args) =>
    execFileSync("git", args, {
      cwd: dir,
      encoding: "utf8",
      stdio: ["ignore", "pipe", "pipe"],
    }).trim();
  try {
    git(["init", "--initial-branch=main"]);
    git(["config", "user.name", "SRM isolated test"]);
    git(["config", "user.email", "test@example.invalid"]);
    const f = dir + "/journal.json";
    const initial = {
      publicationNonce: "initial",
      schemaVersion: "1.0",
      generation: 0,
    };
    fs.writeFileSync(f, JSON.stringify(initial, null, 2) + "\n");
    git(["add", "."]);
    git(["commit", "-m", "base"]);
    const base = git(["rev-parse", "HEAD"]),
      current = { state: initial };
    const proposals = ["first", "second"].map(
      (owner) =>
        publicationFiles(
          current,
          { [journalPath]: { ...initial, generation: 1, owner } },
          base,
        )[journalPath],
    );
    assert.notEqual(
      proposals[0].publicationNonce,
      proposals[1].publicationNonce,
    );
    git(["switch", "-c", "proposal"]);
    fs.writeFileSync(f, JSON.stringify(proposals[0], null, 2) + "\n");
    git(["commit", "-am", "proposal one"]);
    git(["switch", "main"]);
    fs.writeFileSync(dir + "/unrelated.txt", "parallel development\n");
    git(["add", "."]);
    git(["commit", "-m", "unrelated development"]);
    git(["merge", "--no-ff", "proposal", "-m", "lawful publication"]);
    assert.equal(
      fs.readFileSync(dir + "/unrelated.txt", "utf8"),
      "parallel development\n",
    );
    git(["switch", "-c", "stale", base]);
    fs.writeFileSync(f, JSON.stringify(proposals[1], null, 2) + "\n");
    git(["commit", "-am", "proposal two"]);
    git(["switch", "main"]);
    const rejected = spawnSync(
      "git",
      ["merge", "--no-ff", "stale", "-m", "must conflict"],
      { cwd: dir, encoding: "utf8" },
    );
    assert.notEqual(rejected.status, 0);
    assert.match(rejected.stdout, /CONFLICT/);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("domain corrective invalidates old manifest authorization before any write",async()=>{
  const oldContract=structuredClone(contract);delete oldContract.existingDomainBinding;
  const oldManifest={...manifest,contractDigest:digest(oldContract)};
  const f=fixture();
  await assert.rejects(runLifecycle({authorization:{...approval(),manifestDigest:digest(oldManifest)},manifest,provider:f.p,owner:"synthetic-domain"}),/immutable manifest/);
  assert.equal(f.state.generation,0);assert.equal(f.writes.length,0);
});
for(const missing of ["domain","topology"])test("existing domain mismatch stops before claiming the journal: "+missing,async()=>{
  const f=fixture();f.s.services=[{id:contract.existingDomainBinding.serviceId,environmentId:contract.render.environmentId}];
  if(missing==="topology")f.s.domains=[{customDomain:{...contract.existingDomainBinding.domains[0],redirectForName:""}}];
  await assert.rejects(runLifecycle({authorization:approval(),manifest,provider:f.p,owner:"synthetic-domain"}),/domain/i);
  assert.equal(f.state.generation,0);assert.equal(f.writes.length,0);
});
async function fixtureWithExistingDomain(){
  const f=fixture();await runLifecycle({authorization:approval(),manifest,provider:f.p,owner:"synthetic-onboard"});
  f.s.services[0].id=contract.existingDomainBinding.serviceId;
  f.registry.environments.staging.render.services.runtime.serviceId=f.s.services[0].id;
  f.s.domains=[{customDomain:{...contract.existingDomainBinding.domains[0],redirectForName:""}}];
  f.registry.environments.staging.domains=assertStagingDomainBinding(f.s,contract);
  const observe=f.p.observe;
  f.p.observe=async(op,...args)=>op==="service"?{complete:true,result:{},resources:{serviceId:f.s.services[0].id}}:observe(op,...args);
  return f;
}
test("normal promotion records domain evidence and preserves canonical binding",async()=>{
  const f=await fixtureWithExistingDomain();const expected=structuredClone(f.registry.environments.staging.domains);
  const r=await runLifecycle({authorization:{...approval("promote"),approvalId:"synthetic-domain-promote"},manifest,provider:f.p,owner:"synthetic-domain"});
  assert.equal(r.status,"VERIFIED");assert.deepEqual(f.registry.environments.staging.domains,expected);
  assert.deepEqual(f.state.release.proof.domainBindings,expected);
  assert.ok(!f.writes.some(x=>/domain|dns/.test(x)));
});
test("final publication refuses missing or different domain verification proof",async()=>{
  for(const proofDomains of [undefined,[],[{id:"cdm-other"}]]){
    const f=await fixtureWithExistingDomain();const verify=f.p.verify;
    f.p.verify=async(...args)=>({...await verify(...args),domainBindings:proofDomains});
    const baseline=structuredClone(f.state.baseline);
    await assert.rejects(runLifecycle({authorization:{...approval("promote"),approvalId:"synthetic-domain-promote"},manifest,provider:f.p,owner:"synthetic-domain"}),/Domain verification proof/);
    assert.deepEqual(f.state.baseline,baseline);
  }
});

test("provider snapshot reads domains only from exact existing service and never mutates bindings",async()=>{
  const calls=[];const service={id:contract.existingDomainBinding.serviceId,name:contract.render.serviceName,
    ownerId:contract.render.workspaceId,environmentId:contract.render.environmentId,repo:"https://github.com/"+contract.repository,
    autoDeployTrigger:"off",branch:"main",rootDir:contract.render.rootDir,type:"web_service",suspended:"not_suspended",
    serviceDetails:{region:contract.render.region,plan:contract.render.plan,runtime:"node",numInstances:1,
      healthCheckPath:contract.render.healthCheckPath,previews:{generation:"off"},
      envSpecificDetails:{buildCommand:contract.render.buildCommand,startCommand:contract.render.startCommand}}};
  const domain={customDomain:{...contract.existingDomainBinding.domains[0],redirectForName:""}};
  const p=createProvider({RENDER_API_KEY:"synthetic",NEON_API_KEY:"synthetic",SRM_RELEASE_GITHUB_TOKEN:"synthetic"},approval("promote"),manifest,"synthetic-domain",async(url,options)=>{
    calls.push({url,method:options.method});const u=new URL(url);const p=u.pathname;let result;
    if(u.hostname==="api.render.com"){
      if(p.endsWith("/custom-domains"))result=[domain];
      else if(p.endsWith("/deploys"))result=[{deploy:{id:"dep-synthetic",status:"live",commit:{id:sha}}}];
      else if(p.endsWith("/services"))result=[{service}];
      else if(p.includes("/projects/"))result={id:contract.render.projectId,owner:{id:contract.render.workspaceId}};
      else result={id:contract.render.environmentId,projectId:contract.render.projectId,networkIsolationEnabled:true};
    }else if(u.hostname==="console.neon.tech"){
      if(p.endsWith("/databases"))result={databases:[]};
      else if(p.endsWith("/endpoints"))result={endpoints:[{id:contract.neon.endpointId,branch_id:contract.neon.branchId,host:contract.neon.directHost}]};
      else result={branch:{id:contract.neon.branchId,project_id:contract.neon.projectId,name:"Staging",protected:false}};
    }else{
      if(p.endsWith("/secrets"))result={total_count:0,secrets:[]};
      else if(p.includes("/environments/"))result={id:23853126630,name:"srm-staging"};
      else result={id:contract.repositoryId,full_name:contract.repository};
    }
    return new Response(JSON.stringify(result),{status:200});
  });
  const s=await p.snapshot();assert.deepEqual(s.domains,[domain]);
  assert.ok(calls.every(x=>x.method==="GET"));
  assert.equal(calls.filter(x=>x.url.includes("custom-domains")).length,1);
  assert.ok(calls.some(x=>x.url.includes("/services/"+contract.existingDomainBinding.serviceId+"/custom-domains")));
});

async function routineFixture() {
  const f = fixture();
  await runLifecycle({authorization:approval(),manifest,provider:f.p,owner:'github-run:1'});
  f.done.delete('deploy');f.done.delete('verify');
  f.s.liveDeploy.commit.id='b'.repeat(40);f.state.baseline.sha='b'.repeat(40);
  f.registry.environments.staging.render.services.runtime.baselineSha='b'.repeat(40);
  f.writes.length=0;
  return {...f,get state(){return f.state},get registry(){return f.registry},
    authorization:{...approval('promote'),approvalId:'synthetic-routine'}};
}
test('routine promotion groups no-ops, retains mutation fences and uses six publications',async()=>{
  const f=await routineFixture(),publications=[];const commit=f.p.store.commit;
  f.p.store.commit=async input=>{publications.push(structuredClone(input.files[journalPath]));return commit(input)};
  const deploy=f.p.deploy;f.p.deploy=async()=>{
    assert.equal(f.state.release.steps.deploy.status,'INTENT');
    for(const op of ['github-environment','github-bindings','database','schema','service'])
      assert.equal(f.state.release.steps[op].classification,'READ_ONLY_REUSED');
    return deploy();
  };
  await runLifecycle({authorization:f.authorization,manifest,provider:f.p,owner:'github-run:2'});
  assert.equal(publications.length,6);assert.deepEqual(f.writes,['deploy']);
  assert.equal(f.state.release.steps.verify.status,'DONE');assert.equal(f.state.release.phase,'VERIFIED');
  assert.equal(f.state.baseline.sha,sha);assert.equal(f.state.release.manifestDigest,digest(manifest));
  for(let i=1;i<publications.length;i++)assert.equal(publications[i].generation,publications[i-1].generation+1);
});
test('satisfied observation with null result never invokes a redundant mutation',async()=>{
  const f=await routineFixture(),observe=f.p.observe;
  f.p.observe=async(...args)=>{const x=await observe(...args);return args[0]==='database'?{...x,result:null}:x};
  await runLifecycle({authorization:f.authorization,manifest,provider:f.p,owner:'github-run:2'});
  assert.deepEqual(f.writes,['deploy']);assert.equal(f.state.release.steps.database.result,null);
});
for(const [method,operation] of [['githubEnvironment','github-environment'],['githubBindings','github-bindings'],['pinSource','release-pointer'],['database','database'],['schema','schema'],['service','service'],['deploy','deploy'],['rebind','source-rebind'],['verify','verify']])
test('lost effect acknowledgement at '+operation+' is reconciled without a duplicate effect',async()=>{
  const f=fixture(),a=approval(),original=f.p[method];let lost=false;
  f.p[method]=async(...args)=>{const result=await original(...args);if(!lost){lost=true;throw Error('lost acknowledgement')}return result};
  await assert.rejects(runLifecycle({authorization:a,manifest,provider:f.p,owner:'github-run:1'}));
  assert.equal(f.state.release.steps[operation].status,'INTENT');
  const priorEffects=f.writes.filter(x=>x===operation).length;
  await runLifecycle({authorization:a,manifest,provider:f.p,owner:'github-run:1'});
  assert.equal(f.writes.filter(x=>x===operation).length,priorEffects);
  assert.equal(f.state.release.phase,'VERIFIED');assert.equal(f.state.baseline.sha,sha);
});
for(const operation of ['schema','deploy','source-rebind','verify'])for(const acknowledgementLost of [false,true])
test(operation+' DONE publication interruption preserves effect and exact resume ('+acknowledgementLost+')',async()=>{
  const f=fixture(),a=approval(),commit=f.p.store.commit;let failed=false;
  f.p.store.commit=async input=>{
    if(!failed && input.files[journalPath]?.release?.steps[operation]?.status==='DONE'){
      failed=true;if(acknowledgementLost)await commit(input);throw Error('publication interrupted');
    }return commit(input);
  };
  await assert.rejects(runLifecycle({authorization:a,manifest,provider:f.p,owner:'github-run:1'}),e=>e.diagnostic.failureDomain==='RELEASE_BOOKKEEPING');
  const before=f.writes.filter(x=>x===operation).length;
  await runLifecycle({authorization:a,manifest,provider:f.p,owner:'github-run:1'});
  assert.equal(f.writes.filter(x=>x===operation).length,before);assert.equal(f.state.release.phase,'VERIFIED');
});
test('lost final reconciliation acknowledgement resumes VERIFIED read-only',async()=>{
  const f=fixture(),a=approval(),commit=f.p.store.commit;let lost=false;
  f.p.store.commit=async input=>{const r=await commit(input);if(!lost&&input.files[journalPath]?.release?.phase==='VERIFIED'){lost=true;throw Error('lost final acknowledgement')}return r};
  await assert.rejects(runLifecycle({authorization:a,manifest,provider:f.p,owner:'github-run:1'}));
  const before=f.writes.length;f.p.store.commit=async()=>{assert.fail('Completed release cannot publish again')};
  const result=await runLifecycle({authorization:a,manifest,provider:f.p,owner:'github-run:1'});
  assert.equal(result.recovered,true);assert.equal(f.writes.length,before);
});
test('routine grouped observations fail closed after authorization expires before deploy',async()=>{
  const f=await routineFixture(),observe=f.p.observe;
  f.p.observe=async(...args)=>{const result=await observe(...args);if(args[0]==='service')f.authorization.expiresAt=new Date(Date.now()-1).toISOString();return result};
  await assert.rejects(runLifecycle({authorization:f.authorization,manifest,provider:f.p,owner:'github-run:2'}),/expired/);
  assert.deepEqual(f.writes,[]);assert.equal(f.state.release.steps.deploy,undefined);
});
test('unpublished read observations are independently obtained again on same-owner resume',async()=>{
  const f=await routineFixture();let publications=0;const commit=f.p.store.commit;
  f.p.store.commit=async input=>{publications++;return commit(input)};
  await assert.rejects(runLifecycle({authorization:f.authorization,manifest,provider:f.p,owner:'github-run:2',stopAfter:'database'}));
  assert.equal(publications,1);assert.equal(f.state.release.steps.database,undefined);assert.deepEqual(f.writes,[]);
  const observe=f.p.observe,again=[];f.p.observe=async(...args)=>{again.push(args[0]);return observe(...args)};
  await runLifecycle({authorization:f.authorization,manifest,provider:f.p,owner:'github-run:2'});
  assert.ok(again.includes('database'));assert.equal(publications,6);assert.deepEqual(f.writes,['deploy']);
});
test('immutable Git object cache reduces a publication to 19 requests while refreshing main',async()=>{
  const f=publicationFixture(),store=githubStore(f.request);
  const input=publicationInput(await store.read());await store.commit(input);
  assert.equal(f.calls.length,19);assert.equal(f.calls.filter(x=>x.url.endsWith('/branches/main')).length,4);
  assert.equal(f.calls.filter(x=>x.url.includes('/git/trees/')).length,2);
  assert.equal(f.calls.filter(x=>x.url.includes('/git/blobs/')).length,3);
  assert.equal(f.calls.filter(x=>x.url==='/graphql').length,1);
});
test('empty successful inventory avoids polling a missing exact ref and retains exact post-create verification',async()=>{
  const f=publicationFixture();let time=100000;const requests=[],pauses=[];
  const adapter=createGithubRequester(async(full,options)=>{
    const url=full.slice('https://api.github.com'.length);requests.push({url,method:options.method});
    const result=await f.request('https://api.github.com',url,options.method,options.body?JSON.parse(options.body):undefined);
    return new Response(JSON.stringify(result),{status:options.method==='POST'&&url.endsWith('/git/refs')?201:200,
      headers:{'x-poll-interval':url.includes('/matching-refs/')?'300':'0'}});
  },{authorizationExpiresAt:new Date(time+3600000).toISOString(),now:()=>time,pause:async ms=>{pauses.push(ms);time+=ms},emit:()=>{}});
  const store=githubStore((base,url,method='GET',body,options)=>adapter(base+url,{method,body:body?JSON.stringify(body):undefined},'github-rest',options),{now:()=>time,pause:async ms=>{pauses.push(ms);time+=ms}});
  await store.commit(publicationInput(await store.read()));
  assert.deepEqual(pauses,[]);const exact=requests.filter(x=>x.url.includes('/git/ref/heads/'));
  assert.equal(exact.length,1);assert.ok(requests.findIndex(x=>x.method==='POST'&&x.url.endsWith('/git/refs'))<requests.indexOf(exact[0]));
});
for(const inventory of [null,{},[{ref:'refs/heads/foreign',object:{type:'commit',sha}}],Array(2).fill({ref:'other'})])
test('malformed or prefix-collision inventory never authorizes creation '+JSON.stringify(inventory),async()=>{
  const f=publicationFixture(),store=githubStore((base,url,method,body)=>url.includes('/matching-refs/')?inventory:f.request(base,url,method,body));
  await assert.rejects(store.commit(publicationInput(await store.read())));
  assert.ok(!f.calls.some(x=>x.method!=='GET'));
});

test('unchanged-owner resume rejects a concurrent canonical generation before any mutation',async()=>{
  const f=await routineFixture();
  await assert.rejects(runLifecycle({authorization:f.authorization,manifest,provider:f.p,owner:'github-run:2',stopAfter:'database'}));
  const authority=f.p.authority;let raced=false;
  f.p.authority=async(...args)=>{await authority(...args);if(!raced){raced=true;f.state.generation++}};
  await assert.rejects(runLifecycle({authorization:f.authorization,manifest,provider:f.p,owner:'github-run:2'}),/Resume journal changed/);
  assert.deepEqual(f.writes,[]);
});
test('routine no-effect completion is truthful, preserves provider state and requires two publications',async()=>{
  const f=fixture();await runLifecycle({authorization:approval(),manifest,provider:f.p,owner:'github-run:1'});
  const before=f.writes.length;let publications=0;const commit=f.p.store.commit;
  f.p.store.commit=async input=>{publications++;return commit(input)};
  const result=await runLifecycle({authorization:{...approval('promote'),approvalId:'synthetic-no-effect'},manifest,provider:f.p,owner:'github-run:2'});
  assert.equal(publications,2);assert.equal(f.writes.length,before);assert.equal(result.stagingMutated,false);assert.deepEqual(result.mutations,[]);
});

test('new publication transition retains one branch when only observed evidence time changes',async()=>{
  const {publicationBranch}=await import('./staging-lifecycle.mjs');
  const f=publicationFixture({pending:true});let time=0;
  const store=githubStore(f.request,{now:()=>time,pause:async()=>{time++},checkTimeoutMs:1});
  const current=await store.read();const release={publicationIdentityVersion:'2.0',approvalId:'SRM-STAGING-test',manifestDigest:'m',authorizationDigest:'a',owner:'github-run:1',mode:'promote',phase:'PROVISIONING',steps:{deploy:{status:'INTENT',snapshot:{capturedAt:'first'}}}};
  const input={expectedHead:current.head,files:{[journalPath]:{...current.state,generation:1,release}},message:'intent'};
  await assert.rejects(store.commit(input),/CI pending/);
  const fresh=structuredClone(input);fresh.files[journalPath].release.steps.deploy.snapshot.capturedAt='second';
  const originalFiles=publicationFiles(current,input.files,input.expectedHead),freshFiles=publicationFiles(current,fresh.files,fresh.expectedHead);
  assert.notEqual(originalFiles[journalPath].publicationNonce,freshFiles[journalPath].publicationNonce);
  assert.equal(publicationBranch(current,originalFiles),publicationBranch({...current,head:'b'.repeat(40)},freshFiles));
  await assert.rejects(store.commit(fresh),/Publication branch content drift/);
  assert.equal(f.calls.filter(x=>x.method==='POST'&&x.url.endsWith('/git/refs')).length,1);
  assert.equal(f.calls.filter(x=>x.method==='POST'&&x.url.endsWith('/pulls')).length,1);
  assert.equal(f.calls.filter(x=>x.url==='/graphql').length,1);
  f.pending=false;await store.commit(input);assert.equal(f.state.generation,1);
});
test('historical publication branch identity and nonce remain unchanged',async()=>{
  const {publicationBranch}=await import('./staging-lifecycle.mjs');const f=publicationFixture(),current=await githubStore(f.request).read();
  const files=publicationFiles(current,publicationInput(current).files,current.head);
  assert.equal(publicationBranch(current,files),'srm-publication-'+files[journalPath].publicationNonce.slice(0,24));
});


test('successful and completed-release stdout retain adapter request evidence',async()=>{
  const f=fixture(),a=approval();const safe={scope:'SHARED_GITHUB_ADAPTER',attempts:12,endpoints:[]};
  f.p.githubRequestMetrics=()=>structuredClone(safe);
  const first=await runLifecycle({authorization:a,manifest,provider:f.p,owner:'github-run:1'});
  assert.deepEqual(first.githubRequestMetrics,safe);
  const reused=await runLifecycle({authorization:a,manifest,provider:f.p,owner:'github-run:1'});
  assert.deepEqual(reused.githubRequestMetrics,safe);assert.equal(reused.stagingMutated,false);
});
